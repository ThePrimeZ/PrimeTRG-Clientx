# PrimeTRG Client — Minecraft 1.21.11 API migration checklist

This checklist tracks the 46-file compatibility pass requested for the 26.3 → 1.21.11 port. “Source migrated” means the call sites were changed to the 1.21.11 API; it does **not** mean a successful compile has been established. “Audited” means the relevant 1.21.11 API usage was checked and did not need a source change.

| # | File | Migration status | Exact source change / audit | Verification status |
|---:|---|---|---|
| 1 | `src/main/java/net/primetrg/PrimeTRGClient.java` | Audited | Client entrypoint and key category use 1.21.11-compatible types. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 2 | `src/main/java/net/primetrg/command/commands/CmdXRay.java` | Source migrated | Removed 26.3-only `IdentifierException` handling; uses the 1.21.11 identifier parse exception contract. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 3 | `src/main/java/net/primetrg/gui/GuiManager.java` | Source migrated | Uses `GuiGraphics`, `drawString` / `drawCenteredString`, and 1.21.11 GUI drawing calls. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 4 | `src/main/java/net/primetrg/gui/components/EntitiesComponent.java` | Source migrated | Replaced `EntityTypes` references with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 5 | `src/main/java/net/primetrg/gui/components/EntityPreviewComponent.java` | Source migrated | Replaced `EntityTypes`; adapted `SpawnEggItem.byId` to its 1.21.11 nullable `SpawnEggItem` return. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 6 | `src/main/java/net/primetrg/gui/components/ImageComponent.java` | Source migrated | Migrated GUI drawing context and text rendering calls to `GuiGraphics`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 7 | `src/main/java/net/primetrg/gui/components/widgets/PrimeTRGButtonWidget.java` | Source migrated | Replaced extractor-era content rendering with `renderContents`, migrated text drawing calls, and restored default button narration. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 8 | `src/main/java/net/primetrg/gui/components/widgets/PrimeTRGImageButtonWidget.java` | Source migrated | Replaced extractor-era content rendering with `renderContents`, migrated text drawing calls, and restored default button narration. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 9 | `src/main/java/net/primetrg/gui/font/FontManager.java` | Audited | Font set, glyph provider and font option APIs checked against 1.21.11. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 10 | `src/main/java/net/primetrg/gui/screens/MainMenuScreen.java` | Source migrated | Uses `GuiGraphics`, 1.21.11 text drawing methods and the `Screen` render lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 11 | `src/main/java/net/primetrg/gui/screens/PrimeTRGCreditsScreen.java` | Source migrated | Uses `GuiGraphics`, 1.21.11 text drawing methods and the `Screen` render lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 12 | `src/main/java/net/primetrg/gui/screens/PrimeTRGPanorama.java` | Replaced | Replaced 26.3 render-state panorama path with vanilla 1.21.11 `CubeMap` / `PanoramaRenderer`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 13 | `src/main/java/net/primetrg/gui/screens/addons/AddonScreen.java` | Source migrated | Restored `Screen.render`, background and panorama method names. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 14 | `src/main/java/net/primetrg/gui/screens/addons/AddonSelectionList.java` | Source migrated | Uses the 1.21.11 selection-list `renderContent` entrypoint. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 15 | `src/main/java/net/primetrg/gui/screens/alts/AddAltScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render` lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 16 | `src/main/java/net/primetrg/gui/screens/alts/AltScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render` lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 17 | `src/main/java/net/primetrg/gui/screens/alts/AltSelectionList.java` | Source migrated | Uses `PlayerFaceRenderer.draw` and the 1.21.11 list entry render method. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 18 | `src/main/java/net/primetrg/gui/screens/alts/DirectLoginAltScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render` lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 19 | `src/main/java/net/primetrg/gui/screens/alts/EditAltScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render` lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 20 | `src/main/java/net/primetrg/gui/screens/proxy/AddProxyScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render` lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 21 | `src/main/java/net/primetrg/gui/screens/proxy/EditProxyScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render` lifecycle. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 22 | `src/main/java/net/primetrg/gui/screens/proxy/ProxyScreen.java` | Source migrated | Uses the 1.21.11 `Screen.render`, background and panorama methods. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 23 | `src/main/java/net/primetrg/gui/screens/proxy/ProxySelectionList.java` | Source migrated | Uses the 1.21.11 selection-list `renderContent` entrypoint. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 24 | `src/main/java/net/primetrg/managers/SettingManager.java` | Audited | Identifier serialization/parsing APIs remain compatible with 1.21.11. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 25 | `src/main/java/net/primetrg/mixin/AbstractContainerScreenMixin.java` | Source migrated | Uses `OptionalInt` render-pass clear values, `GuiGraphics.renderItem`, `submitMapRenderState`, and the 1.21.11 container-content stream; completed the shulker preview background and deferred draw. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 26 | `src/main/java/net/primetrg/mixin/EntityRendererMixin.java` | Source migrated | Targets 1.21.11 `submitNameTag` / `CameraRenderState` signature. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 27 | `src/main/java/net/primetrg/mixin/GameRendererMixin.java` | Source migrated | Targets 1.21.11 `bobView(PoseStack,float)`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 28 | `src/main/java/net/primetrg/mixin/GuiMixin.java` | Source migrated | Targets 1.21.11 `Gui` render methods and suppresses portal/nausea overlays through `renderPortalOverlay` / `renderConfusionOverlay`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 29 | `src/main/java/net/primetrg/mixin/GuiRendererMixin.java` | Replaced | Removed 26.3-only panorama hooks; retains the GUI renderer tail flush for PrimeTRG's custom HUD. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 30 | `src/main/java/net/primetrg/mixin/LevelExtractorMixin.java` | Removed/migrated | Removed obsolete `LevelExtractor` mixin; nausea overlay behavior moved to `GuiMixin`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 31 | `src/main/java/net/primetrg/mixin/LevelRendererMixin.java` | Replaced | Uses 1.21.11 `renderLevel`, `extractBlockOutline`, `doesMobEffectBlockSky`, `LevelRenderState`, and `Frustum` APIs. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 32 | `src/main/java/net/primetrg/mixin/ScreenEffectRendererMixin.java` | Replaced | Targets 1.21.11 `renderFire` and `renderWater` methods instead of extraction submit hooks. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 33 | `src/main/java/net/primetrg/mixin/ScreenMixin.java` | Source migrated | Targets the 1.21.11 `Screen.render(GuiGraphics,int,int,float)` method. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 34 | `src/main/java/net/primetrg/module/Category.java` | Audited | Identifier use is compatible with 1.21.11. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 35 | `src/main/java/net/primetrg/module/modules/combat/Aimbot.java` | Source migrated | Replaced `EntityTypes` registry constants with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 36 | `src/main/java/net/primetrg/module/modules/combat/AutoTotem.java` | Source migrated | Replaced `EntityTypes` registry constants with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 37 | `src/main/java/net/primetrg/module/modules/combat/BowAimbot.java` | Source migrated | Replaced `EntityTypes` registry constants with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 38 | `src/main/java/net/primetrg/module/modules/combat/KillAura.java` | Source migrated | Replaced `EntityTypes` registry constants with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 39 | `src/main/java/net/primetrg/module/modules/combat/TriggerBot.java` | Source migrated | Replaced `EntityTypes` registry constants with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 40 | `src/main/java/net/primetrg/module/modules/render/EntityESP.java` | Source migrated | Replaced `EntityTypes` registry constants with `EntityType`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 41 | `src/main/java/net/primetrg/rendering/Compositor.java` | Source migrated | Replaced RenderPearl pass/pipeline calls with 1.21.11 `RenderPass`, `GpuBuffer`, `RenderPipelines.GUI_TEXTURED`, projection buffer and indexed draw APIs. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 42 | `src/main/java/net/primetrg/rendering/ModelCapturingCollector.java` | Replaced | Reimplemented against the 1.21.11 `SubmitNodeCollector` method set; captures entity models while consuming unrelated render nodes. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 43 | `src/main/java/net/primetrg/rendering/Renderer2D.java` | Source migrated | Replaced RenderPearl GPU calls, projection buffer, sampler, vertex/index buffer and scissor-stack access; migrated extractor-era text/item drawing methods and kept nested clipping state across widget begin-frame calls. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 44 | `src/main/java/net/primetrg/rendering/Renderer3D.java` | Source migrated | Replaced RenderPearl GPU calls, render-pass setup, mapping and indexed draws; converted rotations to 1.21.11 `PoseStack.mulPose`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 45 | `src/main/java/net/primetrg/rendering/shaders/ShaderManager.java` | Source migrated | Rebuilt pipelines with 1.21.11 `RenderPipeline.Builder` uniform/sampler/blend/vertex-format methods; custom shaders now resolve from `shaders/core`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| 46 | `src/main/java/net/primetrg/rendering/utils/TextureBank.java` | Audited | Identifier and texture-resource naming remain compatible with 1.21.11. | Source-level review only; not compiler-verified (Gradle unavailable). |

## Additional incompatibilities found and migrated during the pass

| File | Migration status | Exact source change / audit | Verification status |
|---|---|---|---|
| `src/main/java/net/primetrg/rendering/AbstractRenderer.java` | Source migrated | 1.21.11 GPU texture creation and `NativeImage` upload path; removed the unavailable texture-matrix accessor. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/rendering/RenderApi.java` | Source migrated | Uses 1.21.11 `GpuDevice` and backend information. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/rendering/shaders/ShaderUniformRingBuffer.java` | Source migrated | Uses 1.21.11 uniform alignment and `CommandEncoder.mapBuffer`. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/rendering/msaa/SSAAHandler.java` | Source migrated | Uses 1.21.11 `TextureFormat` and optional integer render-pass clear values. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/rendering/msaa/IAAHandler.java` | Audited | Uses the 1.21.11 texture-view target contract. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/gui/font/PrimeTRGGlyphProvider.java` | Source migrated | Uses 1.21.11 `NativeImage.Format` texture upload signature. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/mixin/CameraMixin.java` | Replaced | Replaced removed `Camera#setEntity` / `alignWithEntity` injections with `Camera#setup`; updates `initialized`, `level`, `partialTickTime`, and detached state, and returns `FogType.NONE` for Freecam/no-liquid-fog. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/mixin/KeyboardHandlerMixin.java` | Source migrated | Uses `Minecraft.getOverlay()` and the 1.21.11 `KeyEvent.scancode()` accessor. | Source-level review only; not compiler-verified (Gradle unavailable). |
| `src/main/java/net/primetrg/mixin/LocalPlayerMixin.java` | Source migrated | Replaced the removed `sendChanges` injection target with the 1.21.11 `tick` packet-send points; restored Freecam controlled-camera, spectator, and AI-tick hooks. | Source-level review only; not compiler-verified (Gradle unavailable). |

## Verification record (2026-11-20)

- Main production source count: **460 Java files**. Total Java source count including `src/test`: **461**. This archive does not contain 462 Java files; the count is reported from a filesystem walk, not inferred from the earlier request.
- Checklist scope: all **46** specifically identified compatibility files are listed above. Additional affected files are listed separately.
- Migration status describes source edits/audits only. The final column deliberately records each file as **not compiler-verified** because no Minecraft/Fabric compile has completed.
- Actual command attempted: `./gradlew --no-daemon compileJava`.
- Actual result: Gradle Wrapper attempted to download `https://services.gradle.org/distributions/gradle-9.6.0-bin.zip` and failed with `java.net.UnknownHostException: services.gradle.org` before Gradle could configure the project. No Gradle distribution, Gradle executable, Minecraft 1.21.11 client artifact, or Fabric API artifact was present in the local caches.
- Therefore `compileJava`, test execution, `remapJar`, and production `build` are **not verified**. No production JAR is included or claimed.

## Remaining verification

- The Freecam migration now tracks the 1.21.11 `Camera.setup`, `LocalPlayer.tick`, `isControlledCamera`, and spectator/AI hooks.

No remaining occurrences were found for the known removed 26.3 symbols: `GuiGraphicsExtractor`, `EntityTypes`, `IdentifierException`, `LevelExtractor`, `net.minecraft.client.renderer.state.level`, or `com.mojang.renderpearl`.
- Java source parsing completed without syntax diagnostics using JDK 21. This is **not** a Minecraft/Fabric compilation.
- `compileJava`, tests, and production packaging remain unverified because the Gradle wrapper distribution is not available in the local cache and the wrapper cannot resolve `services.gradle.org` in this environment. No JAR is represented as built or verified.
