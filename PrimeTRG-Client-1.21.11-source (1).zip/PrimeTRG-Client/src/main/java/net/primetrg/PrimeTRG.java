/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg;

import net.fabricmc.api.ModInitializer;

/**
 * Initializes and provides access to the PrimeTRG Client singleton.
 */
public class PrimeTRG implements ModInitializer {
	private static PrimeTRGClient INSTANCE;

	@Override
	public void onInitialize() {
		INSTANCE = new PrimeTRGClient();
		INSTANCE.Initialize();
	}

	/**
	 * @return Singleton instance of PrimeTRGClient.
	 */
	public static PrimeTRGClient getInstance() {
		return INSTANCE;
	}
}
