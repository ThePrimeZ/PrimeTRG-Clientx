/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * A class to represent PrimeTRG Client and all of its functions.
 */
package net.primetrg;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;
import net.primetrg.api.IAddon;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.font.FontManager;
import net.primetrg.managers.CombatManager;
import net.primetrg.managers.CommandManager;
import net.primetrg.managers.EntityManager;
import net.primetrg.managers.EventManager;
import net.primetrg.managers.ModuleManager;
import net.primetrg.managers.SettingManager;
import net.primetrg.managers.altmanager.AltManager;
import net.primetrg.managers.macros.MacroManager;
import net.primetrg.managers.proxymanager.ProxyManager;
import net.primetrg.managers.rotation.RotationManager;
import net.primetrg.mixin.interfaces.IMinecraft;
import net.primetrg.module.Module;
import net.primetrg.rendering.AbstractRenderer;
import net.primetrg.rendering.Compositor;
import net.primetrg.rendering.Renderer2D;
import net.primetrg.rendering.Renderer3D;
import net.primetrg.rendering.shaders.ShaderManager;
import net.primetrg.settings.friends.FriendsList;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class PrimeTRGClient {
	public static final KeyMapping.Category PRIMETRG_CATEGORY =
			new KeyMapping.Category(Identifier.fromNamespaceAndPath("primetrg", "category"));

	public static Minecraft MC;
	public static IMinecraft IMC;

	// Systems
	public RotationManager rotationManager;
	public ModuleManager moduleManager;
	public CommandManager commandManager;
	public AltManager altManager;
	public ProxyManager proxyManager;
	public GuiManager guiManager;
	public FontManager fontManager;
	public CombatManager combatManager;
	public SettingManager settingManager;
	public FriendsList friendsList;
	public EventManager eventManager;
	public MacroManager macroManager;
	public EntityManager entityManager;
	public ShaderManager shaderManager;
	public Renderer2D render2D;
	public Renderer3D render3D;
	public Compositor compositor;

	public static List<IAddon> addons = new ArrayList<>();
	public static Logger LOGGER;

	/**
	 * Initializes PrimeTRG Client and creates sub-systems.
	 */
	public void Initialize() {
		// Gets instance of Minecraft
		MC = Minecraft.getInstance();
		IMC = (IMinecraft) MC;
		LOGGER = LogUtils.getLogger();
	}

	/**
	 * Initializes systems and loads any assets.
	 */
	public void loadAssets() {
		LOGGER.info("[PrimeTRG] Starting Client");
		eventManager = new EventManager();

		// Register any addons.
		LogUtils.getLogger().info("[PrimeTRG] Starting addon initialization");
		for (EntrypointContainer<IAddon> entrypoint : FabricLoader.getInstance().getEntrypointContainers("primetrg",
				IAddon.class)) {
			IAddon addon = entrypoint.getEntrypoint();

			try {
				LOGGER.info("[PrimeTRG] Initializing addon: " + addon.getName());
				addon.onInitialize();
				LOGGER.info("[PrimeTRG] Addon initialized: " + addon.getName());
			} catch (Throwable e) {
				LOGGER.error("Error initializing addon: " + addon.getName(), e);
			}

			addons.add(addon);
		}

		LOGGER.info("[PrimeTRG] Reading Settings");
		settingManager = new SettingManager();

		LOGGER.info("[PrimeTRG] Reading Friends List");
		friendsList = new FriendsList();

		LOGGER.info("[PrimeTRG] Initializing Commands");
		commandManager = new CommandManager(addons);

		LOGGER.info("[PrimeTRG] Initializing Font Manager");
		fontManager = new FontManager();
		fontManager.Initialize();

		LOGGER.info("[PrimeTRG] Initializing Combat Manager");
		combatManager = new CombatManager();

		LOGGER.info("[PrimeTRG] Initializing Entity Manager");
		entityManager = new EntityManager();

		LOGGER.info("[PrimeTRG] Initializing Macro Manager");
		macroManager = new MacroManager();

		LOGGER.info("[PrimeTRG] Initializing Shader Effects");
		shaderManager = new ShaderManager();
		
		LOGGER.info("[PrimeTRG] Initializing Renderers");
		compositor = new Compositor();
		render2D = new Renderer2D();
		render3D = new Renderer3D();

		LOGGER.info("[PrimeTRG] Initializing Rotation Manager");
		rotationManager = new RotationManager();
		
		LOGGER.info("[PrimeTRG] Initializing Modules");
		moduleManager = new ModuleManager(addons);
		
		LOGGER.info("[PrimeTRG] Initializing GUI");
		guiManager = new GuiManager();
		guiManager.Initialize();

		LOGGER.info("[PrimeTRG] Loading Settings");
		SettingManager.loadGlobalSettings();
		SettingManager.loadSettings();

		LOGGER.info("[PrimeTRG] Initializing Alt Manager");
		altManager = new AltManager();

		LOGGER.info("[PrimeTRG] Initializing Proxy Manager");
		proxyManager = new ProxyManager();

		LOGGER.info("[PrimeTRG] Registering Shutdown Hook");
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				endClient();
			} catch (Exception e) {
				LOGGER.error("[PrimeTRG] Error during shutdown: ", e);
			}
		}));

		LOGGER.info("[PrimeTRG] PrimeTRG-chan initialized and ready to play!");
	}

	/**
	 * Called when the client is shutting down. Saves persistent data.
	 */
	public void endClient() {
		LOGGER.info("[PrimeTRG] Shutting down");
		try {
			SettingManager.saveSettings();
			altManager.saveAlts();
			friendsList.save();
			macroManager.save();
			moduleManager.modules.forEach(Module::onDisable);
		} catch (Exception e) {
			LOGGER.error("[PrimeTRG] Error saving data", e);
		}

		try {
			if (render2D != null) render2D.close();
			if (render3D != null) render3D.close();
			if (compositor != null) compositor.close();
			AbstractRenderer.closeSharedResources();
		} catch (Exception e) {
			LOGGER.error("[PrimeTRG] Error releasing renderer resources", e);
		}
	}
}
