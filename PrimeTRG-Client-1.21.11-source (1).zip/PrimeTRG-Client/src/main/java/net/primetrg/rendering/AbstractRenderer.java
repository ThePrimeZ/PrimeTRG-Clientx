package net.primetrg.rendering;


import org.jspecify.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import net.primetrg.rendering.shaders.ShaderUniformRingBuffer;

public abstract class AbstractRenderer implements AutoCloseable {
	protected static final int VERTEX_BUFFER_USAGE = GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE;
	protected static final Matrix4f IDENTITY_MATRIX = new Matrix4f();

	private static @Nullable GpuTexture whiteTexture;
	private static @Nullable GpuTextureView whiteTextureView;
	private static @Nullable GpuSampler whiteSampler;

	private final ShaderUniformRingBuffer shaderParamsBuffer = new ShaderUniformRingBuffer();

	public static GpuBufferSlice uploadGuiTransform() {
		return RenderSystem.getDynamicUniforms().writeTransform(new Matrix4f().setTranslation(0f, 0f, -11000f),
				new Vector4f(1f, 1f, 1f, 1f), new Vector3f(0f, 0f, 0f), new Matrix4f());
	}

	public static GpuBufferSlice uploadIdentityTransform() {
		return RenderSystem.getDynamicUniforms().writeTransform(new Matrix4f(), new Vector4f(1f, 1f, 1f, 1f),
				new Vector3f(0f, 0f, 0f), new Matrix4f());
	}

	public abstract void render();

	@Override
	public abstract void close();

	/**
	 * Lazily creates the 1x1 white pixel texture.
	 */
	public static void ensureWhiteTexture() {
		if (whiteTextureView != null)
			return;

		whiteTexture = RenderSystem.getDevice().createTexture("primetrg_white_pixel",
				GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_COPY_DST, TextureFormat.RGBA8, 1, 1, 1, 1);

		whiteTextureView = RenderSystem.getDevice().createTextureView(whiteTexture);

		try (NativeImage pixel = new NativeImage(1, 1, false)) {
			pixel.setPixelABGR(0, 0, 0xFFFFFFFF);
			RenderSystem.getDevice().createCommandEncoder().writeToTexture(whiteTexture, pixel);
		}

		whiteSampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST);
	}

	public static GpuTextureView getWhiteTextureView() {
		return whiteTextureView;
	}

	public static GpuSampler getWhiteSampler() {
		return whiteSampler;
	}

	public ShaderUniformRingBuffer getShaderParamsBuffer() {
		return shaderParamsBuffer;
	}

	public static void closeSharedResources() {
		if (whiteTextureView != null) {
			whiteTextureView.close();
			whiteTextureView = null;
		}
		if (whiteTexture != null) {
			whiteTexture.close();
			whiteTexture = null;
		}
		whiteSampler = null;
	}
}
