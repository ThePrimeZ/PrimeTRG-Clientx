package net.primetrg.rendering;

import java.util.List;

import org.joml.Quaternionf;
import org.jspecify.annotations.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.OrderedSubmitNodeCollector;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.MovingBlockRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.model.Model;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.phys.Vec3;

/** Captures the model submitted by the entity renderer for ESP model overlays. */
public final class ModelCapturingCollector implements SubmitNodeCollector {
	private @Nullable Model<?> captured;

	public void reset() { captured = null; }
	public @Nullable Model<?> getCaptured() { return captured; }

	@Override
	public <S> void submitModel(Model<? super S> model, S state, PoseStack poseStack, RenderType renderType,
			int lightCoords, int overlayCoords, int tintedColor, @Nullable TextureAtlasSprite sprite, int outlineColor,
			@Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
		if (captured == null) captured = model;
	}

	@Override
	public OrderedSubmitNodeCollector order(int order) { return this; }

	@Override
	public void submitShadow(PoseStack poseStack, float radius, List<EntityRenderState.ShadowPiece> pieces) { }

	@Override
	public void submitNameTag(PoseStack poseStack, @Nullable Vec3 nameTagAttachment, int offset, Component name,
			boolean seeThrough, int lightCoords, double distanceToCameraSq, CameraRenderState camera) { }

	@Override
	public void submitText(PoseStack poseStack, float x, float y, FormattedCharSequence string, boolean dropShadow,
			Font.DisplayMode displayMode, int lightCoords, int color, int backgroundColor, int outlineColor) { }

	@Override
	public void submitFlame(PoseStack poseStack, EntityRenderState renderState, Quaternionf rotation) { }

	@Override
	public void submitLeash(PoseStack poseStack, EntityRenderState.LeashState leashState) { }

	@Override
	public void submitMovingBlock(PoseStack poseStack, MovingBlockRenderState movingBlockRenderState) { }

	@Override
	public void submitBlockModel(PoseStack poseStack, RenderType renderType, net.minecraft.client.renderer.block.model.BlockStateModel model,
			float red, float green, float blue, int lightCoords, int overlayCoords, int outlineColor) { }

	@Override
	public void submitItem(PoseStack poseStack, ItemDisplayContext displayContext, int lightCoords, int overlayCoords,
			int outlineColor, int[] tintLayers, List<BakedQuad> quads, RenderType renderType,
			ItemStackRenderState.FoilType foilType) { }

	@Override
	public void submitCustomGeometry(PoseStack poseStack, RenderType renderType,
			SubmitNodeCollector.CustomGeometryRenderer customGeometryRenderer) { }

	@Override
	public void submitParticleGroup(SubmitNodeCollector.ParticleGroupRenderer particleGroupRenderer) { }
}
