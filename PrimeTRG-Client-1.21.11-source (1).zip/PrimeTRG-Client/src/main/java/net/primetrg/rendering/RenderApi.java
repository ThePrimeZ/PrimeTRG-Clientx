package net.primetrg.rendering;

import java.util.Locale;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.GpuDevice;

import net.primetrg.PrimeTRGClient;

/**
 * Represents a set of known / implemented Render APIS
 * for use with the rendering pipelines.
 */
public enum RenderApi {
	OPENGL,
	VULKAN;

	private static RenderApi cached;

	/**
	 * Returns the active rendering backend.
	 */
	public static RenderApi current() {
		if (cached == null) {
			GpuDevice device = RenderSystem.tryGetDevice();
			if (device == null) {
				// Device not initialized yet. Don't cache it yet.
				return OPENGL;
			}
			String backend = device.getBackendName();
			cached = backend != null && backend.toLowerCase(Locale.ROOT).contains("vulkan") ? VULKAN : OPENGL;
			PrimeTRGClient.LOGGER.info("[PrimeTRG] Render API: " + (cached == VULKAN ? "Vulkan" : "OpenGL"));
		}
		return cached;
	}
}
