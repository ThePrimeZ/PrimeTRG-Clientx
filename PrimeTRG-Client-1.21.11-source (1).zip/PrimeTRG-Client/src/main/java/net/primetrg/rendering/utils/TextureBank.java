/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.rendering.utils;

import net.minecraft.resources.Identifier;

public class TextureBank {
	public static final Identifier container = Identifier.fromNamespaceAndPath("primetrg", "textures/hud/container.png");
	public static final Identifier mainmenu_logo = Identifier.fromNamespaceAndPath("primetrg", "textures/mainmenu/primetrg-name.png");
	public static final Identifier primetrg = Identifier.fromNamespaceAndPath("primetrg", "textures/primetrg.png");
	public static final Identifier gear = Identifier.fromNamespaceAndPath("primetrg", "textures/gear.png");
	public static final Identifier discord = Identifier.fromNamespaceAndPath("primetrg", "textures/mainmenu/discord.png");
	public static final Identifier mainmenu_panorama = Identifier.fromNamespaceAndPath("primetrg", "textures/mainmenu/panorama");
	public static final Identifier combat = Identifier.fromNamespaceAndPath("primetrg", "textures/combat.png");
	public static final Identifier misc = Identifier.fromNamespaceAndPath("primetrg", "textures/misc.png");
	public static final Identifier movement = Identifier.fromNamespaceAndPath("primetrg", "textures/movement.png");
	public static final Identifier render = Identifier.fromNamespaceAndPath("primetrg", "textures/render.png");
	public static final Identifier world = Identifier.fromNamespaceAndPath("primetrg", "textures/world.png");
}
