/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.module.modules.movement;

import net.primetrg.PrimeTRG;
import net.primetrg.event.events.TickEvent.Post;
import net.primetrg.event.events.TickEvent.Pre;
import net.primetrg.event.listeners.TickListener;
import net.primetrg.module.AntiCheat;
import net.primetrg.module.Category;
import net.primetrg.module.Module;

public class ReverseStep extends Module implements TickListener {
	public ReverseStep() {
		super("ReverseStep");
		setCategory(Category.of("Movement"));
		setDescription("Steps. But in reverse...");

		setDetectable(
		    AntiCheat.NoCheatPlus,
		    AntiCheat.Vulcan,
		    AntiCheat.AdvancedAntiCheat,
		    AntiCheat.Grim,
		    AntiCheat.Matrix,
		    AntiCheat.Karhu
		);
	}

	@Override
	public void onDisable() {
		PrimeTRG.getInstance().eventManager.RemoveListener(TickListener.class, this);
	}

	@Override
	public void onEnable() {
		PrimeTRG.getInstance().eventManager.AddListener(TickListener.class, this);
	}

	@Override
	public void onToggle() {

	}

	@Override
	public void onTick(Pre event) {
		if (MC.player.onGround()) {
			MC.player.setDeltaMovement(MC.player.getDeltaMovement().x, MC.player.getDeltaMovement().y - 1.0,
					MC.player.getDeltaMovement().z);
		}
	}

	@Override
	public void onTick(Post event) {

	}
}
