package net.primetrg.module.modules.combat;

import net.primetrg.PrimeTRG;
import net.primetrg.event.events.StartAttackEvent;
import net.primetrg.event.listeners.StartAttackListener;
import net.primetrg.module.Category;
import net.primetrg.module.Module;
import net.minecraft.world.phys.HitResult;

public class NoMissDelay extends Module implements StartAttackListener {
	public NoMissDelay() {
		super("NoMissDelay");
		
		setCategory(Category.of("Combat"));
		setDescription("Prevents you from swinging while looking at air");
	}

	@Override
	public void onDisable() {
		PrimeTRG.getInstance().eventManager.RemoveListener(StartAttackListener.class, this);
	}

	@Override
	public void onEnable() {
		PrimeTRG.getInstance().eventManager.AddListener(StartAttackListener.class, this);
	}

	@Override
	public void onToggle() {
		
	}

	@Override
	public void onStartAttack(StartAttackEvent event) {
		if(MC.hitResult != null && MC.hitResult.getType() == HitResult.Type.MISS) {
			event.cancel();
		}
	}
}
