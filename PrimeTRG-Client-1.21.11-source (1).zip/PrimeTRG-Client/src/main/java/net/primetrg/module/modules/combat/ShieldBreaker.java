package net.primetrg.module.modules.combat;

import net.primetrg.PrimeTRG;
import net.primetrg.event.events.StartAttackEvent;
import net.primetrg.event.listeners.StartAttackListener;
import net.primetrg.module.Category;
import net.primetrg.module.Module;
import net.primetrg.utils.FindItemResult;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class ShieldBreaker extends Module implements StartAttackListener {
	public ShieldBreaker() {
		super("ShieldBreaker");
		
		setCategory(Category.of("Combat"));
		setDescription("Renders an opponents shield useless. Requires an axe to be in your hotbar.");
	}

	@Override
	public void onDisable() {
		PrimeTRG.getInstance().eventManager.RemoveListener(StartAttackListener.class, this);
	}

	@Override
	public void onEnable() {
		PrimeTRG.getInstance().eventManager.AddListener(StartAttackListener.class, this);
	}

	@Override
	public void onToggle() {

	}

	@Override
	public void onStartAttack(StartAttackEvent event) {

		Entity target = event.getTarget();
		if (target == null)
			return;
		
		// Ensure that target HAS a shield and is currently blocking.
		if(target instanceof LivingEntity livingTarget) {
			if(livingTarget.isBlocking()) {
				FindItemResult findItemResult = findInHotbar(s -> s.is(ItemTags.AXES));
				if (findItemResult.found() && swap(findItemResult.slot(), true)) {
					event.cancel();

					// Note: we do not want to use InteractionUtils.attack() here
					// Doing so will infinitely bubble the onStartAttack event.
					MC.gameMode.attack(MC.player, target);
					MC.player.swing(InteractionHand.MAIN_HAND, MC.player.getMainHandItem().getAttackAnimation(), false);
					MC.player.connection.send(ServerboundPunchPacket.INSTANCE);

					swapBack();
				}
			}
		}
	}
}