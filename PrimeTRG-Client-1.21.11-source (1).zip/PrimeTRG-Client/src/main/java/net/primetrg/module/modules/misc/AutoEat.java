/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.module.modules.misc;

import net.primetrg.PrimeTRG;
import net.primetrg.PrimeTRGClient;
import net.primetrg.event.events.FoodLevelEvent;
import net.primetrg.event.events.ItemUsedEvent;
import net.primetrg.event.events.PlayerHealthEvent;
import net.primetrg.event.listeners.FoodLevelListener;
import net.primetrg.event.listeners.ItemUsedListener;
import net.primetrg.event.listeners.PlayerHealthListener;
import net.primetrg.module.Category;
import net.primetrg.module.Module;
import net.primetrg.settings.types.BooleanSetting;
import net.primetrg.settings.types.FloatSetting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class AutoEat extends Module implements FoodLevelListener, PlayerHealthListener, ItemUsedListener {
	private ItemStack lastUsedItemStack = null;
	private int previousSlot = -1;
	private boolean isEating = false;

	private final BooleanSetting swapBack = BooleanSetting.builder().id("autoeat_swap_back").displayName("Swap Back")
			.description("Whether the player's slot will be switched back to their previous slot after eating.")
			.defaultValue(true).build();

	private final BooleanSetting fillToFull = BooleanSetting.builder().id("autoeat_fill_to_hull")
			.displayName("Fill To Full").description("Whether to fill the player's hunger to full.").defaultValue(true)
			.build();

	private final FloatSetting hungerSetting = FloatSetting.builder().id("autoeat_hunger").displayName("Hunger")
			.description("Determines when AutoEat will trigger.").defaultValue(10f).minValue(1f).maxValue(20f).step(1f)
			.build();

	private final FloatSetting healthSetting = FloatSetting.builder().id("autoeat_health").displayName("Health")
			.description("Determines when AutoEat will trigger based on health.").defaultValue(10f).minValue(1f)
			.maxValue(20f).step(1f).build();

	private final BooleanSetting prioritizeGapples = BooleanSetting.builder().id("autoeat_prioritize_gapples")
			.displayName("Prioritize Gapples").description("Prioritizes enchanted golden apples and golden apples.")
			.defaultValue(true).build();

	public AutoEat() {
		super("AutoEat");

		setCategory(Category.of("Misc"));
		setDescription("Automatically eats the best food in your inventory.");

		addSetting(fillToFull);
		addSetting(swapBack);
		addSetting(hungerSetting);
		addSetting(healthSetting);
		addSetting(prioritizeGapples);
	}

	@Override
	public void onDisable() {
		PrimeTRG.getInstance().eventManager.RemoveListener(FoodLevelListener.class, this);
		PrimeTRG.getInstance().eventManager.RemoveListener(PlayerHealthListener.class, this);
		PrimeTRG.getInstance().eventManager.RemoveListener(ItemUsedListener.class, this);
	}

	@Override
	public void onEnable() {
		PrimeTRG.getInstance().eventManager.AddListener(FoodLevelListener.class, this);
		PrimeTRG.getInstance().eventManager.AddListener(PlayerHealthListener.class, this);
		PrimeTRG.getInstance().eventManager.AddListener(ItemUsedListener.class, this);
	}

	@Override
	public void onToggle() {

	}

	public void setHunger(int hunger) {
		hungerSetting.setValue((float) hunger);
	}

	public void setHealth(float health) {
		healthSetting.setValue(health);
	}

	private boolean shouldEat() {
		if (isEating && fillToFull.getValue()) {
			return MC.player.getFoodData().needsFood();
		} else {
			int foodLevel = MC.player.getFoodData().getFoodLevel();
			return foodLevel <= hungerSetting.getValue();
		}
	}

	private boolean healthBelowThreshold() {
		float health = MC.player.getHealth();
		return health <= healthSetting.getValue();
	}

	private boolean isCurrentlyHandEdible() {
		Item item = MC.player.getInventory().getSelectedItem().getItem();
		FoodProperties food = item.components().get(DataComponents.FOOD);
		return food != null;
	}

	private void eatIfNecessary() {
		if (MC.player == null)
			return;

		if (shouldEat() || healthBelowThreshold()) {
			// Eat what is in the current hand.
			if (isCurrentlyHandEdible()) {
				MC.options.keyUse.setDown(true);
				isEating = true;
			} else {
				// Else find the hand to eat and start eating.
				int foodSlot = -1;
				FoodProperties bestFood = null;

				for (int i = 0; i < 9; i++) {
					Item item = MC.player.getInventory().getItem(i).getItem();
					FoodProperties food = item.components().get(DataComponents.FOOD);
					if (food == null)
						continue;

					if (prioritizeGapples.getValue()) {
						if (item == Items.ENCHANTED_GOLDEN_APPLE) {
							bestFood = food;
							foodSlot = i;
							break;
						} else if (item == Items.GOLDEN_APPLE) {
							bestFood = food;
							foodSlot = i;
						}
					}

					if (bestFood != null) {
						if (food.nutrition() > bestFood.nutrition() && item != Items.GOLDEN_APPLE
								&& item != Items.ENCHANTED_GOLDEN_APPLE) {
							bestFood = food;
							foodSlot = i;
						}
					} else {
						bestFood = food;
						foodSlot = i;
					}
				}

				if (bestFood != null) {
					if (swapBack.getValue()) {
						previousSlot = MC.player.getInventory().getSelectedSlot();
						PrimeTRGClient.LOGGER.info("[PrimeTRG] Setting previous slot to: " + previousSlot);
					}

					lastUsedItemStack = MC.player.getInventory().getItem(foodSlot);
					isEating = true;
					PrimeTRGClient.LOGGER.info("[PrimeTRG] Eating Slot: " + foodSlot);
					MC.player.getInventory().setSelectedSlot(foodSlot);
					MC.options.keyUse.setDown(true);
				}
			}
		}
	}

	@Override
	public void onFoodLevelChanged(FoodLevelEvent readPacketEvent) {
		eatIfNecessary();
	}

	@Override
	public void onHealthChanged(PlayerHealthEvent readPacketEvent) {
		eatIfNecessary();
	}

	@Override
	public void onItemUsed(ItemUsedEvent.Pre event) {

	}

	@Override
	public void onItemUsed(ItemUsedEvent.Post event) {
		PrimeTRGClient.LOGGER.info("[PrimeTRG] Item POST");
		if (lastUsedItemStack != null && ItemStack.isSameItem(event.getItemStack(), lastUsedItemStack)) {
			PrimeTRGClient.LOGGER.info("[PrimeTRG] EATING Item was used");
			boolean shouldContinueEating = shouldEat();
			if (!shouldContinueEating) {
				MC.options.keyUse.setDown(false);
				lastUsedItemStack = null;
				PrimeTRGClient.LOGGER.info("[PrimeTRG]No longer eating : " + previousSlot);
				isEating = false;
				if (swapBack.getValue() && previousSlot != -1) {
					PrimeTRGClient.LOGGER.info("[PrimeTRG] Swapping back to : " + previousSlot);
					MC.player.getInventory().setSelectedSlot(previousSlot);
					previousSlot = -1;
				}
			}
		}
	}
}