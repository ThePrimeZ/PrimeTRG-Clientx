/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.module.modules.misc;

import net.primetrg.PrimeTRG;
import net.primetrg.event.events.SendPacketEvent;
import net.primetrg.event.listeners.SendPacketListener;
import net.primetrg.module.AntiCheat;
import net.primetrg.module.Category;
import net.primetrg.module.Module;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;

public class XCarry extends Module implements SendPacketListener {
	public XCarry() {
		super("XCarry");
		setCategory(Category.of("Misc"));
		setDescription("Allows you to store items in your crafting slot..");

		isDetectable(AntiCheat.Negativity);
	}

	@Override
	public void onDisable() {
		PrimeTRG.getInstance().eventManager.RemoveListener(SendPacketListener.class, this);
	}

	@Override
	public void onEnable() {
		PrimeTRG.getInstance().eventManager.AddListener(SendPacketListener.class, this);
	}

	@Override
	public void onToggle() {

	}

	@Override
	public void onSendPacket(SendPacketEvent event) {
		Packet<?> packet = event.GetPacket();
		if (packet instanceof ServerboundContainerClosePacket closeScreenPacket) {
            if (closeScreenPacket.getContainerId() == MC.player.inventoryMenu.containerId)
				event.cancel();
		}
	}
}
