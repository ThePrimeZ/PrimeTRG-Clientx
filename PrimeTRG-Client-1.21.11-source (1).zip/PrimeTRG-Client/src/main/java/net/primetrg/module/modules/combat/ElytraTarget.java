package net.primetrg.module.modules.combat;

import net.primetrg.PrimeTRG;
import net.primetrg.event.events.SubtickEvent;
import net.primetrg.event.events.TickEvent;
import net.primetrg.event.listeners.SubtickListener;
import net.primetrg.event.listeners.TickListener;
import net.primetrg.managers.rotation.RotationMode;
import net.primetrg.managers.rotation.goals.EasingFunction;
import net.primetrg.managers.rotation.goals.EntityGoal;
import net.minecraft.world.phys.Vec3;
import net.primetrg.module.Category;
import net.primetrg.module.Module;
import net.primetrg.settings.types.BooleanSetting;
import net.primetrg.settings.types.EnumSetting;
import net.primetrg.settings.types.FloatSetting;
import net.primetrg.utils.FindItemResult;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.FireworkRocketItem;
import net.minecraft.world.item.Items;

public class ElytraTarget extends Module implements SubtickListener, TickListener {

	private LivingEntity target = null;
	private int currentFireworkTick = 0;
	private int currentAimTick = 0;
	private int swapBackDelayTick = 0;
	private int useDelayTick = -1;
	private int previousSlot = -1;
	
	private final BooleanSetting targetFriends = BooleanSetting.builder().id("elytratarget_target_friends")
			.displayName("Target Friends").description("Target Friends.").defaultValue(true).build();

	private final FloatSetting interval = FloatSetting.builder().id("elytratarget_interval").displayName("Fireworks Interval")
			.description("How often to use fireworks").defaultValue(10.0f).minValue(1.0f)
			.maxValue(40.0f).step(1.0f).build();
	
	private final FloatSetting frequency = FloatSetting.builder().id("elytratarget_frequency").displayName("Ticks")
			.description("How frequent the aimbot updates (Lower = Laggier)").defaultValue(1.0f).minValue(1.0f)
			.maxValue(20.0f).step(1.0f).build();

	private final FloatSetting radius = FloatSetting.builder().id("elytratarget_radius").displayName("Radius")
			.description("Radius that the aimbot will lock onto a target.").defaultValue(64.0f).minValue(1.0f)
			.maxValue(256.0f).step(1.0f).build();

	private final EnumSetting<RotationMode> rotationMode = EnumSetting.<RotationMode>builder()
			.id("elytratarget_rotation_mode").displayName("Rotation Mode")
			.description("Controls how the player's view rotates.").defaultValue(RotationMode.SMOOTH).build();

	private final FloatSetting maxRotation = FloatSetting.builder().id("elytratarget_max_rotation")
			.displayName("Max Rotation").description("The max speed that Aimbot will rotate").defaultValue(50.0f)
			.minValue(1.0f).maxValue(360.0f).build();

	private final EnumSetting<EasingFunction> easingFunction = EnumSetting.<EasingFunction>builder()
			.id("elytratarget_easing").displayName("Easing")
			.description("Easing curve applied to the rotation speed as it approaches the target.")
			.defaultValue(EasingFunction.SineEaseInOut).build();

	private final FloatSetting yawRandomness = FloatSetting.builder().id("elytratarget_yaw_randomness")
			.displayName("Yaw Rotation Jitter").description("The randomness of the player's yaw").defaultValue(0.5f)
			.minValue(0.0f).maxValue(10.0f).step(0.1f).build();

	private final FloatSetting pitchRandomness = FloatSetting.builder().id("elytratarget_pitch_randomness")
			.displayName("Pitch Rotation Jitter").description("The randomness of the player's pitch").defaultValue(0.3f)
			.minValue(0.0f).maxValue(10.0f).step(0.1f).build();

	private final BooleanSetting fakeRotation = BooleanSetting.builder().id("elytratarget_fake_rotation")
			.displayName("Fake Rotation")
			.description("Spoofs the client's rotation so that the player appears rotated on the server")
			.defaultValue(false).build();
	
	private final BooleanSetting useRaycast = BooleanSetting.builder().id("elytratarget_use_raycast")
			.displayName("Use Raycast")
			.description("Whether the player must be visible to fly to.")
			.defaultValue(true).build();

	private final FloatSetting useDelay = FloatSetting.builder().id("elytratarget_use_delay")
			.displayName("Use Delay")
			.description("Delay in ticks between swapping to fireworks and using them.")
			.defaultValue(3.0f).minValue(1.0f).maxValue(10.0f).step(1.0f).build();

	private final FloatSetting swapDelay = FloatSetting.builder().id("elytratarget_swap_delay")
			.displayName("Swap Delay")
			.description("Delay in ticks between using the firework and swapping back.")
			.defaultValue(4.0f).minValue(3.0f).maxValue(10.0f).step(1.0f).build();

	private final BooleanSetting moveFix = BooleanSetting.builder().id("elytratarget_move_fix")
			.displayName("Move Fix")
			.description("Corrects movement to match spoofed rotation by using the server yaw for velocity.")
			.defaultValue(false).build();


	public ElytraTarget() {
		super("ElytraTarget");
		setCategory(Category.of("Combat"));
		setDescription("Locks your crosshair towards a desired player or entity and uses fireworks to fly towards them.");
		addSetting(targetFriends);
		addSetting(interval);
		addSetting(frequency);
		addSetting(radius);
		addSetting(rotationMode);
		addSetting(maxRotation);
		addSetting(easingFunction);
		addSetting(yawRandomness);
		addSetting(pitchRandomness);
		addSetting(fakeRotation);
		addSetting(useRaycast);
		addSetting(useDelay);
		addSetting(swapDelay);
		addSetting(moveFix);
	}

	@Override
	public void onDisable() {
		PrimeTRG.getInstance().eventManager.RemoveListener(SubtickListener.class, this);
		PrimeTRG.getInstance().eventManager.RemoveListener(TickListener.class, this);
		PrimeTRG.getInstance().rotationManager.setGoal(null);
		currentFireworkTick = 0;
		swapBackDelayTick = 0;
		useDelayTick = -1;
		if (previousSlot != -1) {
			swap(previousSlot, false);
			previousSlot = -1;
		}
	}

	@Override
	public void onEnable() {
		PrimeTRG.getInstance().eventManager.AddListener(SubtickListener.class, this);
		PrimeTRG.getInstance().eventManager.AddListener(TickListener.class, this);
	}

	@Override
	public void onToggle() {

	}

	@Override
	public void onSubtick(SubtickEvent event) {
		boolean flying = MC.player.isFallFlying() && MC.player.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
		if (!flying) {
			PrimeTRG.getInstance().rotationManager.setGoal(null);
			return;
		}

		currentAimTick++;
		if (currentAimTick >= frequency.getValue()) {
			float partialTick = MC.getDeltaTracker().getGameTimeDeltaPartialTick(true);
			Vec3 playerPos = MC.player.getPosition(partialTick);

			target = null;
			float radiusSqr = radius.getValueSqr();

			for (AbstractClientPlayer entity : MC.level.players()) {
				if (entity == MC.player)
					continue;

				if (!targetFriends.getValue() && PrimeTRG.getInstance().friendsList.contains(entity))
					continue;

				double entityDistanceToPlayer = entity.getPosition(partialTick).distanceToSqr(playerPos);
				if (entityDistanceToPlayer >= radiusSqr)
					continue;

				if (target == null || entityDistanceToPlayer < target.getPosition(partialTick).distanceToSqr(playerPos)) {
					target = entity;
				}
			}

			if (target != null) {
				EntityGoal rotation = EntityGoal.builder().goal(target).mode(rotationMode.getValue())
						.maxRotation(maxRotation.getValue()).pitchRandomness(pitchRandomness.getValue())
						.yawRandomness(yawRandomness.getValue()).fakeRotation(fakeRotation.getValue())
						.moveFix(moveFix.getValue()).easingFunction(easingFunction.getValue()).build();
				PrimeTRG.getInstance().rotationManager.setGoal(rotation);
			} else {
				PrimeTRG.getInstance().rotationManager.setGoal(null);
			}

			currentAimTick = 0;
		}
	}

	@Override
	public void onTick(TickEvent.Pre event) {

	}

	@Override
	public void onTick(TickEvent.Post event) {
		boolean flying = MC.player.isFallFlying() && MC.player.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);

		// Swap back to the player's old hand when they are not flying anymore.
		if (!flying && previousSlot != -1) {
			swap(previousSlot, false);
			previousSlot = -1;
			useDelayTick = -1;
			swapBackDelayTick = 0;
			return;
		}

		// Return early if the player is not flying.
		if (!flying) {
			return;
		}

		// We have previously swapped to the fireworks, so now we wait
		// until the value of useDelay amount of ticks have passed.
		if (previousSlot != -1 && useDelayTick >= 0) {
			useDelayTick++;
			if (useDelayTick >= useDelay.getValue()) {
				MC.gameMode.useItem(MC.player, InteractionHand.MAIN_HAND);
				useDelayTick = -1;
				swapBackDelayTick = 0;
			}
			return;
		}

		// If waiting to swap back, count down the delay before swapping back to the old slot.
		if (previousSlot != -1) {
			swapBackDelayTick++;
			if (swapBackDelayTick >= swapDelay.getValue()) {
				swap(previousSlot, false);
				previousSlot = -1;
				swapBackDelayTick = 0;
			}
			return;
		}

		if (target != null) {
			// Check if useRaycast is disabled OR if enabled, check if the target is within the player's line of sight.
			if (!useRaycast.getValue() || MC.player.hasLineOfSight(target)) {
				if (currentFireworkTick >= interval.getValue()) {
					FindItemResult findItemResult = findInHotbar(s -> s.getItem() instanceof FireworkRocketItem);
					if (findItemResult.found()) {
						previousSlot = MC.player.getInventory().getSelectedSlot();
						swap(findItemResult.slot(), false);
						useDelayTick = 0;
					}
					currentFireworkTick = 0;
				}
			}
		}
		currentFireworkTick++;
	}
}