package net.primetrg.event.listeners;

import net.primetrg.event.events.StartAttackEvent;

public interface StartAttackListener extends AbstractListener {
	void onStartAttack(StartAttackEvent event);
}
