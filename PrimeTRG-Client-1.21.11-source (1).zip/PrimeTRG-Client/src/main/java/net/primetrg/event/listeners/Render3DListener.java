/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.event.listeners;

import net.primetrg.event.events.Render3DEvent;

public interface Render3DListener extends AbstractListener {
	void onRender(Render3DEvent event);
}
