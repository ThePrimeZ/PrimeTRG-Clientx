/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.components.widgets;

import static net.primetrg.PrimeTRGClient.MC;

import java.util.function.Consumer;

import net.primetrg.PrimeTRG;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.colors.Colors;
import net.minecraft.client.gui.GuiGraphics;
import net.primetrg.rendering.Renderer2D;
import net.primetrg.rendering.shaders.Shader;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.input.InputWithModifiers;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public class PrimeTRGImageButtonWidget extends AbstractButton {
	private Consumer<PrimeTRGImageButtonWidget> pressAction;
	private final Identifier image;
	private boolean background = true;
	private static final Shader IMAGE_SHADER = Shader.solid(Colors.White);

	public PrimeTRGImageButtonWidget(int x, int y, int width, int height, Identifier image) {
		super(x, y, width, height, Component.empty());

		this.image = image;
	}

	public PrimeTRGImageButtonWidget(int x, int y, int width, int height, Identifier image,
			boolean background) {
		super(x, y, width, height, Component.empty());

		this.image = image;
		this.background = background;
	}

	public void setPressAction(Consumer<PrimeTRGImageButtonWidget> pressAction) {
		this.pressAction = pressAction;
	}

	@Override
	public void onPress(InputWithModifiers input) {
		if (pressAction != null) {
			pressAction.accept(this);
		}
	}

	@Override
	protected void renderContents(GuiGraphics graphics, int mouseX, int mouseY, float a) {
		if (background) {
			Shader bgEffect = isHovered() ? GuiManager.buttonHoverBackgroundColor.getValue()
					: GuiManager.buttonBackgroundColor.getValue();
			Shader bdEffect = GuiManager.buttonBorderColor.getValue();

			Renderer2D renderer = PrimeTRG.getInstance().render2D;
			renderer.beginFrame(graphics, MC.getDeltaTracker());
			renderer.drawOutlinedRoundedBox(getX(), getY(), width, height,
					GuiManager.roundingRadius.getValue(), bdEffect, bgEffect);
			renderer.drawTexturedQuad(image, getX(), getY(), width, height, IMAGE_SHADER);
		}
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput output) {
		defaultButtonNarrationText(output);
	}
}