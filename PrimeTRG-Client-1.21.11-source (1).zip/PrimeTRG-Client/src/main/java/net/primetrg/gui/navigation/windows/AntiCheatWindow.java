/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.navigation.windows;

import java.util.Arrays;
import net.primetrg.PrimeTRG;
import net.primetrg.gui.components.ComboBoxComponent;
import net.primetrg.gui.components.SeparatorComponent;
import net.primetrg.gui.components.StackPanelComponent;
import net.primetrg.gui.components.StringComponent;
import net.primetrg.gui.font.FontManager;
import net.primetrg.gui.navigation.Window;
import net.primetrg.gui.types.BindingMode;
import net.primetrg.gui.types.SizeToContent;
import net.primetrg.module.AntiCheat;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.UIElement;

/**
 * Represents the AntiCheat Window that allows the user to select their
 * anticheat.
 */
public class AntiCheatWindow extends Window {
	public AntiCheatWindow() {
		super("AntiCheat", 50, 990);
		sizeToContent = SizeToContent.Both;
		StackPanelComponent stackPanel = new StackPanelComponent();
		stackPanel.setSpacing(8f);
		
		StringComponent headerText = new StringComponent("AntiCheat Settings");
		headerText.setProperty(UIElement.FontWeightProperty, FontManager.WEIGHT_BOLD);
		headerText.bindProperty(ForegroundProperty, GuiManager.foregroundHeaderColor);
		stackPanel.addChild(headerText);
	
		stackPanel.addChild(new SeparatorComponent());
		
		ComboBoxComponent comboBox = new ComboBoxComponent();
		comboBox.setProperty(ComboBoxComponent.ItemsSourceProperty, Arrays.asList(AntiCheat.values()));
		comboBox.bindProperty(ComboBoxComponent.SelectedItemProperty, PrimeTRG.getInstance().moduleManager.antiCheat, BindingMode.TwoWay);
		stackPanel.addChild(comboBox);
		
		StringComponent detailText = new StringComponent("The selected AC will disable any features that are KNOWN detectable by that AC.");
		detailText.bindProperty(UIElement.ForegroundProperty, GuiManager.foregroundAccentColor);
		stackPanel.addChild(detailText);
		setContent(stackPanel);
		
		setProperty(UIElement.MinWidthProperty, 300f);
	}
}
