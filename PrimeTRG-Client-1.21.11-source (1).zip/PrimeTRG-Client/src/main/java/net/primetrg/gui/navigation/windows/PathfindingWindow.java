/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.navigation.windows;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.commons.lang3.math.NumberUtils;
import net.primetrg.PrimeTRG;
import net.primetrg.event.events.Render3DEvent;
import net.primetrg.event.events.TickEvent;
import net.primetrg.event.listeners.Render3DListener;
import net.primetrg.event.listeners.TickListener;
import net.primetrg.gui.colors.Colors;
import net.primetrg.gui.font.FontManager;
import net.primetrg.gui.components.ButtonComponent;
import net.primetrg.gui.components.CheckboxComponent;
import net.primetrg.gui.components.ComboBoxComponent;
import net.primetrg.gui.components.GridComponent;
import net.primetrg.gui.components.SeparatorComponent;
import net.primetrg.gui.components.SliderComponent;
import net.primetrg.gui.components.StackPanelComponent;
import net.primetrg.gui.components.StringComponent;
import net.primetrg.gui.components.TextBoxComponent;
import net.primetrg.gui.navigation.Window;
import net.primetrg.gui.types.BindingMode;
import net.primetrg.gui.types.GridDefinition;
import net.primetrg.gui.types.SizeToContent;
import net.primetrg.gui.types.Thickness;
import net.primetrg.gui.types.GridDefinition.RelativeUnit;
import net.primetrg.managers.SettingManager;
import net.primetrg.managers.pathfinding.AbstractPathManager;
import net.primetrg.managers.pathfinding.FlyPathManager;
import net.primetrg.managers.pathfinding.PathNode;
import net.primetrg.managers.pathfinding.TeleportPathManager;
import net.primetrg.managers.pathfinding.WalkingPathManager;
import net.primetrg.rendering.shaders.Shader;
import net.primetrg.settings.types.BooleanSetting;
import net.primetrg.settings.types.EnumSetting;
import net.primetrg.settings.types.FloatSetting;
import net.primetrg.settings.types.StringSetting;
import net.primetrg.utils.player.MovementUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.VegetationBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.UIElement;

public class PathfindingWindow extends Window implements TickListener, Render3DListener {

	public enum Pathfinder {
		Walk, Fly, Teleport,
	}

	private static final Minecraft MC = Minecraft.getInstance();
	private static final ExecutorService executor = Executors.newSingleThreadExecutor();

	private final ButtonComponent startButton;
	private final StringComponent startButtonText;
	private final ButtonComponent setPositionButton;
	private SliderComponent radiusSlider;
	private SliderComponent flyMaxSpeedSlider;

	private final EnumSetting<Pathfinder> pathfinderMode;
	private final BooleanSetting avoidWater;
	private final BooleanSetting avoidLava;
	private final FloatSetting radius;
	private final StringSetting locationX;
	private final StringSetting locationY;
	private final StringSetting locationZ;
	private final FloatSetting maxSpeed;

	private final Runnable startRunnable;
	private final Runnable clearRunnable;
	private final Runnable setPositionRunnable;
	private BlockPos start;
	private BlockPos end;
	private BlockPos actualEnd;
	private AbstractPathManager pathManager;

	private int currentNodeIndex = 0;
	private ArrayList<PathNode> nodes;
	private boolean isStarted = false;

	public PathfindingWindow() {
		super("Pathfinding", 540, 150);
		sizeToContent = SizeToContent.Both;
		setProperty(UIElement.MinWidthProperty, 350f);

		pathfinderMode = EnumSetting.<Pathfinder>builder().id("goto_pathfinder_mode").displayName("Mode")
				.defaultValue(Pathfinder.Walk).onUpdate(var -> {
					switch (var) {
					case Fly:
						pathManager = new FlyPathManager();
						break;
					case Walk:
						pathManager = new WalkingPathManager();
						break;
					case Teleport:
						pathManager = new TeleportPathManager();
						break;
					}

					// Disable Radius setting if not teleport
					radiusSlider.setProperty(UIElement.IsVisibleProperty, var == Pathfinder.Teleport);
					flyMaxSpeedSlider.setProperty(UIElement.IsVisibleProperty, var == Pathfinder.Fly);

					if (isStarted)
						recalculatePathAsync();
				}).build();

		avoidWater = BooleanSetting.builder().id("goto_avoid_water").displayName("Avoid Water")
				.description("Whether the pathfinder will avoid Water").defaultValue(false).onUpdate(var -> {
					pathManager.setAvoidWater(var);
					if (isStarted)
						recalculatePathAsync();
				}).build();

		avoidLava = BooleanSetting.builder().id("goto_avoid_lava").displayName("Avoid Lava")
				.description("Whether the pathfinder will avoid Lava").defaultValue(false).onUpdate(var -> {
					pathManager.setAvoidLava(var);
					if (isStarted)
						recalculatePathAsync();
				}).build();

		radius = FloatSetting.builder().id("goto_radius").displayName("Teleport Radius")
				.description("The radius that the teleport pathfinder will attempt to find a block within.")
				.defaultValue(5.0f).minValue(1.0f).maxValue(100.0f).step(1.0f).onUpdate(s -> {
					if (pathManager instanceof TeleportPathManager tpManager) {
						tpManager.setRadius(s);
						if (isStarted)
							recalculatePathAsync();
					}
				}).build();

		locationX = StringSetting.builder().id("goto_location_x").displayName("X Coord").description("X Coordinate")
				.build();

		locationY = StringSetting.builder().id("goto_location_y").displayName("Y Coord").description("Y Coordinate")
				.build();

		locationZ = StringSetting.builder().id("goto_location_z").displayName("Z Coord").description("Z Coordinate")
				.build();

		maxSpeed = FloatSetting.builder().id("goto_max_speed").displayName("Max Speed").description("Max Speed")
				.defaultValue(4.0f).minValue(0.5f).maxValue(15.0f).step(0.5f).build();

		// Register Settings
		SettingManager.registerSetting(pathfinderMode);
		SettingManager.registerSetting(avoidWater);
		SettingManager.registerSetting(avoidLava);
		SettingManager.registerSetting(radius);
		SettingManager.registerSetting(locationX);
		SettingManager.registerSetting(locationY);
		SettingManager.registerSetting(locationZ);
		SettingManager.registerSetting(maxSpeed);

		StackPanelComponent stackPanel = new StackPanelComponent();
		stackPanel.setSpacing(8f);
		
		StringComponent header = new StringComponent("PathFinding");
		header.setProperty(UIElement.FontWeightProperty, FontManager.WEIGHT_BOLD);
		header.bindProperty(UIElement.ForegroundProperty, GuiManager.foregroundHeaderColor);
		stackPanel.addChild(header);
		stackPanel.addChild(new SeparatorComponent());

		StringComponent label = new StringComponent(
				"Automatically walks/flies your player to specific coordinates.");
		stackPanel.addChild(label);

		ComboBoxComponent pathfinderModeComponent = new ComboBoxComponent();
		pathfinderModeComponent.setProperty(ComboBoxComponent.ItemsSourceProperty, List.of(pathfinderMode.getValue().getClass().getEnumConstants()));
		pathfinderModeComponent.bindProperty(ComboBoxComponent.SelectedItemProperty, pathfinderMode, BindingMode.TwoWay);
		stackPanel.addChild(pathfinderModeComponent);
		
		stackPanel.addChild(pathfinderModeComponent);

		CheckboxComponent avoidWaterCheckbox = new CheckboxComponent();
		avoidWaterCheckbox.setProperty(CheckboxComponent.HeaderProperty, avoidWater.displayName);
		avoidWaterCheckbox.bindProperty(CheckboxComponent.IsCheckedProperty, avoidWater, BindingMode.TwoWay);
		stackPanel.addChild(avoidWaterCheckbox);

		CheckboxComponent avoidLavaCheckbox = new CheckboxComponent();
		avoidLavaCheckbox.setProperty(CheckboxComponent.HeaderProperty, avoidLava.displayName);
		avoidLavaCheckbox.bindProperty(CheckboxComponent.IsCheckedProperty, avoidLava, BindingMode.TwoWay);
		stackPanel.addChild(avoidLavaCheckbox);

		radiusSlider = new SliderComponent();
		radiusSlider.setProperty(SliderComponent.HeaderProperty, radius.displayName);
		radiusSlider.setProperty(SliderComponent.MinimumProperty, radius.min_value);
		radiusSlider.setProperty(SliderComponent.MaximumProperty, radius.max_value);
		radiusSlider.bindProperty(SliderComponent.ValueProperty, radius, BindingMode.TwoWay);
		stackPanel.addChild(radiusSlider);

		flyMaxSpeedSlider = new SliderComponent();
		flyMaxSpeedSlider.setProperty(SliderComponent.HeaderProperty, maxSpeed.displayName);
		flyMaxSpeedSlider.setProperty(SliderComponent.MinimumProperty, maxSpeed.min_value);
		flyMaxSpeedSlider.setProperty(SliderComponent.MaximumProperty, maxSpeed.max_value);
		flyMaxSpeedSlider.bindProperty(SliderComponent.ValueProperty, maxSpeed, BindingMode.TwoWay);
		stackPanel.addChild(flyMaxSpeedSlider);

		stackPanel.addChild(new StringComponent("X Coordinate"));
		TextBoxComponent locationXTextBox = new TextBoxComponent();
		locationXTextBox.bindProperty(TextBoxComponent.TextProperty, locationX, BindingMode.TwoWay);
		stackPanel.addChild(locationXTextBox);

		stackPanel.addChild(new StringComponent("Y Coordinate"));
		TextBoxComponent locationYTextBox = new TextBoxComponent();
		locationYTextBox.bindProperty(TextBoxComponent.TextProperty, locationY, BindingMode.TwoWay);
		stackPanel.addChild(locationYTextBox);

		stackPanel.addChild(new StringComponent("Z Coordinate"));
		TextBoxComponent locationZTextBox = new TextBoxComponent();
		locationZTextBox.bindProperty(TextBoxComponent.TextProperty, locationZ, BindingMode.TwoWay);
		stackPanel.addChild(locationZTextBox);

		startRunnable = new Runnable() {
			@Override
			public void run() {
				startButtonText.setProperty(StringComponent.TextProperty, "Cancel");
				startButton.setOnClick(clearRunnable);
				isStarted = true;
				recalculatePathAsync();
				registerEvents();
			}
		};

		clearRunnable = new Runnable() {
			@Override
			public void run() {
				unregisterEvents();
				clear();
				MovementUtils.stopMoving();
				startButtonText.setProperty(StringComponent.TextProperty, "Calculate");
				startButton.setOnClick(startRunnable);
			}
		};

		setPositionRunnable = new Runnable() {
			@Override
			public void run() {
				Minecraft MC = Minecraft.getInstance();
				BlockPos pos = MC.player.blockPosition();
				locationX.setValue(String.valueOf(pos.getX()));
				locationY.setValue(String.valueOf(pos.getY()));
				locationZ.setValue(String.valueOf(pos.getZ()));
			}
		};

		GridComponent buttonGrid = new GridComponent();
		buttonGrid.addColumnDefinition(new GridDefinition(1, RelativeUnit.Relative));
		buttonGrid.addColumnDefinition(new GridDefinition(1, RelativeUnit.Relative));
		buttonGrid.setProperty(GridComponent.HorizontalSpacingProperty, 8f);
		
		startButton = new ButtonComponent(startRunnable);
		startButton.setProperty(UIElement.PaddingProperty, new Thickness(8f));
		startButtonText = new StringComponent("Calculate");
		startButton.setContent(startButtonText);
		buttonGrid.addChild(startButton);

		setPositionButton = new ButtonComponent(setPositionRunnable);
		setPositionButton.setProperty(UIElement.PaddingProperty, new Thickness(8f));
		setPositionButton.setContent(new StringComponent("Set Position"));
		buttonGrid.addChild(setPositionButton);

		stackPanel.addChild(buttonGrid);
		setContent(stackPanel);

		pathManager = new WalkingPathManager();
	}

	private void recalculatePathAsync() {
		executor.submit(this::recalculatePath);
	}

	private void registerEvents() {

		PrimeTRG.getInstance().eventManager.AddListener(Render3DListener.class, this);
		PrimeTRG.getInstance().eventManager.AddListener(TickListener.class, this);
	}

	private void unregisterEvents() {
		PrimeTRG.getInstance().eventManager.RemoveListener(Render3DListener.class, this);
		PrimeTRG.getInstance().eventManager.RemoveListener(TickListener.class, this);
	}

	private void recalculatePath() {
		BlockPos targetPos = getNextTarget();

		int x = Integer.parseInt(locationX.getValue());
		int y = Integer.parseInt(locationY.getValue());
		int z = Integer.parseInt(locationZ.getValue());

		pathManager.setTarget(targetPos);
		nodes = pathManager.recalculatePath(MC.player.blockPosition());

		start = MC.player.blockPosition();
		end = targetPos;
		actualEnd = new BlockPos(x, y, z);
		currentNodeIndex = 0;
	}

	private BlockPos getNextTarget() {
		if (!NumberUtils.isParsable(locationX.getValue()) || !NumberUtils.isParsable(locationY.getValue())
				|| !NumberUtils.isParsable(locationZ.getValue()))
			return null;

		int x = Integer.parseInt(locationX.getValue());
		int y = Integer.parseInt(locationY.getValue());
		int z = Integer.parseInt(locationZ.getValue());
		Vec3 target = new Vec3(x, y, z);

		BlockPos targetPos = new BlockPos(x, y, z);

		ChunkPos targetChunkPos = new ChunkPos(SectionPos.blockToSectionCoord(targetPos.getX()),
				SectionPos.blockToSectionCoord(targetPos.getZ()));

		// Find the new chunk / position that we want to try to get to, hoping that we
		// can find one.
		BlockPos playerPos = MC.player.blockPosition();
		Vec3 delta = target.subtract(Vec3.atCenterOf(playerPos)).normalize();
		Vec3 offset = new Vec3(delta.x, delta.y, delta.z);
		BlockPos newTarget = playerPos;
		BlockPos temp = playerPos;
		boolean foundTargetInLoadedChunks = false;

		ChunkPos chunkPos = new ChunkPos(SectionPos.blockToSectionCoord(temp.getX()),
				SectionPos.blockToSectionCoord(temp.getZ()));

		// HashSet<Chunk> visittedChunks = new HashSet<Chunk>();
		while (MC.level.getChunkSource().hasChunk(chunkPos.x(), chunkPos.z())) {
			newTarget = temp;
			temp = playerPos.offset((int) Math.ceil(offset.x), (int) Math.ceil(offset.y), (int) Math.ceil(offset.z));
			offset = offset.add(delta);
			chunkPos = new ChunkPos(SectionPos.blockToSectionCoord(temp.getX()),
					SectionPos.blockToSectionCoord(temp.getZ()));

			// visittedChunks.add(chunk);
			if (chunkPos.equals(targetChunkPos)) {
				newTarget = targetPos;
				foundTargetInLoadedChunks = true;
				break;
			}
		}

		// We want to ensure that if we could NOT find the loaded chunk, that we move to
		// the highest point in the middle of that chunk.
		// If it doesn't, it is possible that the target would be inside of the bllock.
		if (!foundTargetInLoadedChunks)
			newTarget = getHighestBlock(newTarget);

		return newTarget;
	}

	private BlockPos getHighestBlock(BlockPos current) {
		boolean isTeleportMode = pathfinderMode.getValue() == Pathfinder.Teleport;
		BlockPos prevPos = null;
		for (int i = 320; i >= -64; i--) {
			BlockPos pos = current.atY(i);
			BlockState state = MC.level.getBlockState(pos);

			
			if ((isTeleportMode && !state.isAir() && !state.getFluidState().is(FluidTags.WATER)
					&& !state.getFluidState().is(FluidTags.LAVA) && !(state.getBlock() instanceof VegetationBlock))
					|| (!isTeleportMode && !state.isAir()))
				break;

			prevPos = pos;
		}

		if (pathfinderMode.getValue() == Pathfinder.Fly) {
			if (prevPos.getY() >= current.getY())
				return prevPos;
			else
				return current;
		} else
			return prevPos;
	}

	private void clear() {
		nodes = null;
		isStarted = false;
	}

	@Override
	public void onRender(Render3DEvent event) {
		if (nodes != null) {
			AABB startBox = new AABB(start);
			AABB endBox = new AABB(end);

			event.getRenderer().drawBox(startBox, Shader.solid(Colors.Red), 1.0f);
			event.getRenderer().drawBox(endBox, Shader.solid(Colors.Red), 1.0f);

			for (int i = 0; i < nodes.size() - 1; i++) {
				PathNode first = nodes.get(i);
				PathNode second = nodes.get(i + 1);

				Vec3 pos1 = Vec3.atCenterOf(first.pos).add(-0.15f, -0.15f, -0.15f);
				Vec3 pos2 = Vec3.atCenterOf(first.pos).add(0.15f, 0.15f, 0.15f);
				AABB box = new AABB(pos1.x, pos1.y, pos1.z, pos2.x, pos2.y, pos2.z);

				event.getRenderer().drawBox(box, Shader.solid(Colors.Red), 1);
				event.getRenderer().drawLine(Vec3.atCenterOf(first.pos),
						Vec3.atCenterOf(second.pos), Shader.solid(Colors.Red));
			}
		}
	}

	@Override
	public void onTick(TickEvent.Pre event) {

	}

	@Override
	public void onTick(TickEvent.Post event) {
		Minecraft MC = Minecraft.getInstance();
		if (nodes == null)
			return;

		if (currentNodeIndex < nodes.size() - 1) {
			// Check next position
			PathNode next = nodes.get(currentNodeIndex + 1);
			BlockPos playerPos;

			if (MC.player.isHandsBusy()) {
				Entity riding = MC.player.getRootVehicle();
				playerPos = riding.blockPosition();
			} else
				playerPos = MC.player.blockPosition();

			if (playerPos.equals(next.pos)) {
				currentNodeIndex++;
				if (currentNodeIndex < nodes.size() - 1)
					next = nodes.get(currentNodeIndex + 1);
				else {
					MovementUtils.stopMoving();
					return;
				}
			}startButtonText.setProperty(StringComponent.TextProperty, "Calculate");

			Vec3 nextCenterPos = Vec3.atBottomCenterOf(next.pos);

			switch (pathfinderMode.getValue()) {
			case Fly:
				double velocity = Math.min(maxSpeed.getValue(), MC.player.position().distanceTo(nextCenterPos));
				Vec3 direction = nextCenterPos.subtract(MC.player.position()).normalize().scale(velocity);

				// Check to see if the player is in a vehicle. If they are, we want to apply
				// velocity to the vehicle (boatfly)
				if (MC.player.isHandsBusy()) {
					Entity riding = MC.player.getRootVehicle();
					riding.lookAt(Anchor.EYES, new Vec3(nextCenterPos.x, MC.player.getEyeY(), nextCenterPos.z));
					riding.setDeltaMovement(direction);
				} else
					MC.player.setDeltaMovement(direction);
				break;
			case Walk:
				MC.player.getAbilities().flying = false;
				MC.player.lookAt(Anchor.EYES, new Vec3(nextCenterPos.x, MC.player.getEyeY(), nextCenterPos.z));
				MC.options.keyUp.setDown(true);
				MC.options.keyJump.setDown(next.getIsInWater() || next.getIsInLava() || next.getWasJump()
						|| MC.player.horizontalCollision);
				break;
			case Teleport:
				int packetsRequired = (int) Math.ceil(MC.player.position().distanceTo(nextCenterPos) / 10) - 1;

				for (int i = 0; i < packetsRequired; i++) {
					MC.player.connection.send(new ServerboundMovePlayerPacket.StatusOnly(true, false));
				}

				MC.player.connection.send(new ServerboundMovePlayerPacket.Pos(nextCenterPos.x,
						nextCenterPos.y, nextCenterPos.z, true, false));
				MC.player.setPos(nextCenterPos);
				break;
			default:
				break;
			}
		} else {
			// Check to see if we actually reached the destination. If not, we want to
			// recalculate the path.
			if (!actualEnd.equals(end)) {
				recalculatePathAsync();
			} else {
				PrimeTRG.getInstance().eventManager.RemoveListener(Render3DListener.class, this);
				PrimeTRG.getInstance().eventManager.RemoveListener(TickListener.class, this);
				clear();
				startButtonText.setProperty(StringComponent.TextProperty, "Calculate");
				startButton.setOnClick(startRunnable);
			}
		}
	}
}