package net.primetrg.gui.screens;

import net.primetrg.rendering.utils.TextureBank;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.CubeMap;
import net.minecraft.client.renderer.PanoramaRenderer;
import net.minecraft.client.renderer.texture.TextureManager;

/** Vanilla 1.21.11 panorama renderer used by the PrimeTRG menu screens. */
public final class PrimeTRGPanorama {
    private final CubeMap cubeMap = new CubeMap(TextureBank.mainmenu_panorama);
    private final PanoramaRenderer panoramaRenderer = new PanoramaRenderer(cubeMap);
    private boolean texturesRegistered;

    public void render(GuiGraphics graphics, int width, int height, boolean shouldSpin) {
        if (!texturesRegistered) {
            TextureManager textureManager = Minecraft.getInstance().getTextureManager();
            panoramaRenderer.registerTextures(textureManager);
            texturesRegistered = true;
        }
        panoramaRenderer.render(graphics, width, height, shouldSpin);
    }
}
