/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.navigation.windows;

import java.util.ArrayList;
import net.primetrg.gui.UIElement;
import net.primetrg.gui.components.HudComponent;
import net.primetrg.gui.components.SeparatorComponent;
import net.primetrg.gui.components.StackPanelComponent;
import net.primetrg.gui.components.StringComponent;
import net.primetrg.gui.font.FontManager;
import net.primetrg.gui.navigation.HudWindow;
import net.primetrg.gui.navigation.Window;
import net.primetrg.gui.types.SizeToContent;
import net.primetrg.gui.GuiManager;

public class ToggleHudsTab extends Window {
	public ToggleHudsTab(ArrayList<HudWindow> huds) {
		super("Toggle HUDs", 0, 0);
		sizeToContent = SizeToContent.Both;
		StackPanelComponent stackPanel = new StackPanelComponent();
		stackPanel.setSpacing(8f);
		
		StringComponent header = new StringComponent("Toggle HUDs");
		header.setProperty(UIElement.FontWeightProperty, FontManager.WEIGHT_BOLD);
		header.bindProperty(UIElement.ForegroundProperty, GuiManager.foregroundHeaderColor);
		stackPanel.addChild(header);
		
		stackPanel.addChild(new SeparatorComponent());

		for (HudWindow hud : huds) {
			HudComponent hudComponent = new HudComponent(hud.getID(), hud);
			stackPanel.addChild(hudComponent);
		}

		setContent(stackPanel);
		setProperty(UIElement.MinWidthProperty, 300f);
	}
}
