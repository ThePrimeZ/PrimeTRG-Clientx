/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.screens.proxy;

import org.jetbrains.annotations.Nullable;

import net.primetrg.PrimeTRG;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.colors.Colors;
import net.primetrg.managers.proxymanager.Socks5Proxy;
import net.primetrg.rendering.shaders.Shader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.util.Util;

public class ProxySelectionList extends ObjectSelectionList<ProxySelectionList.Entry> {
	private final ProxyScreen owner;

	public ProxySelectionList(ProxyScreen ownerIn, Minecraft minecraftClient, int i, int j, int k, int l) {
		super(minecraftClient, i, j, k, l);
		owner = ownerIn;
	}

	public void setSelected(@Nullable ProxySelectionList.Entry entry) {
		super.setSelected(entry);
		if (entry != null) {
			owner.setEdittable();
		}
	}

	@Override
	public boolean keyPressed(KeyEvent keyEvent) {
		Entry entry = getSelected();
		return entry != null && entry.keyPressed(keyEvent) || super.keyPressed(keyEvent);
	}

	public void updateProxies() {
		clearEntries();

		for (Socks5Proxy proxy : owner.getProxyList()) {
			ProxySelectionList.NormalEntry entry = new ProxySelectionList.NormalEntry(owner, proxy);
			addEntry(entry);
		}
	}

	@Environment(value = EnvType.CLIENT)
	public static abstract class Entry extends ObjectSelectionList.Entry<ProxySelectionList.Entry> implements AutoCloseable {
		@Override
		public void close() {
		}
	}

	public class NormalEntry extends ProxySelectionList.Entry {
		private final ProxyScreen owner;
		private final Socks5Proxy proxy;
		private long lastClickTime;

		protected NormalEntry(ProxyScreen ownerIn, Socks5Proxy proxy) {
			owner = ownerIn;
			this.proxy = proxy;
		}

		public void getProxyList() {
			owner.getProxyList();
		}

		public Socks5Proxy getProxyData() {
			return proxy;
		}

		@Override
		public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
			owner.setSelected(this);
			if (Util.getMillis() - lastClickTime < 250L) {
				Socks5Proxy proxy = getProxyData();
				if (owner.isActiveProxy(proxy)) {
					owner.resetActive();
				} else {
					owner.setActive();
				}
			}
			lastClickTime = Util.getMillis();
			return true;
		}

		@Override
		public Component getNarration() {
			return Component.nullToEmpty(proxy.getIp());
		}

		@Override
		public void renderContent(GuiGraphics graphics, int mouseX, int mouseY, boolean hovered, float a) {
			int x = getX();
			int y = getY();
			int lineHeight = 12;

			Shader textColor = Shader.solid(
					owner.isActiveProxy(proxy) ? Colors.Green :Colors.White);

			Font font = GuiManager.fontSetting.getValue().getRenderer();
			PrimeTRG.getInstance().render2D.drawStringWithScale("IP: " + proxy.getIp(), x + 32 + 3, y, textColor, 1.0f, font);
			PrimeTRG.getInstance().render2D.drawStringWithScale( "Port: " + proxy.getPort(), x + 32 + 3, y + lineHeight,
					textColor, 1.0f, font);
			PrimeTRG.getInstance().render2D.drawStringWithScale( "Username: " + proxy.getUsername(), x + 32 + 3,
					y + lineHeight * 2, textColor, 1.0f, font);
			PrimeTRG.getInstance().render2D.drawStringWithScale( "*".repeat(proxy.getPassword().length()), x + 32 + 3,
					y + lineHeight * 3, textColor, 1.0f, font);
		}
	}
}
