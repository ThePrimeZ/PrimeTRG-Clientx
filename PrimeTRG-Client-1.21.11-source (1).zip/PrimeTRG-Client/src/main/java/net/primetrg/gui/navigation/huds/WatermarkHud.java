/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.navigation.huds;

import net.primetrg.gui.GuiManager;
import net.primetrg.gui.UIElement;
import net.primetrg.gui.navigation.HudWindow;
import net.primetrg.gui.types.Rectangle;
import net.primetrg.gui.types.ResizeMode;
import net.primetrg.rendering.Renderer2D;

public class WatermarkHud extends HudWindow {

	public WatermarkHud(int x, int y) {
		super("WatermarkHud", x, y, 50, 24);
		setProperty(UIElement.MinWidthProperty, 50f);
		setProperty(UIElement.MinHeightProperty, 20f);
		setProperty(UIElement.MaxHeightProperty, 20f);
		resizeMode = ResizeMode.None;
	}

	@Override
	public void draw(Renderer2D renderer, float partialTicks) {
		boolean isVisible = getProperty(UIElement.IsVisibleProperty);
		if (isVisible) {
			Rectangle pos = position.getValue();
			String watermarkText = "PrimeTRG Client";
			renderer.drawString(watermarkText, pos.x(), pos.y(),
					GuiManager.foregroundColor.getValue(), GuiManager.fontSetting.getValue().getRenderer());
		}

		super.draw(renderer, partialTicks);
	}
}
