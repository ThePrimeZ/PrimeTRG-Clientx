/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.gui.components;

import net.primetrg.PrimeTRG;
import net.primetrg.gui.UIElement;
import net.primetrg.gui.colors.Color;
import net.primetrg.gui.colors.Colors;
import net.primetrg.gui.navigation.HudWindow;
import net.primetrg.gui.types.GridDefinition;
import net.primetrg.gui.types.VerticalAlignment;
import net.primetrg.gui.types.GridDefinition.RelativeUnit;
import net.primetrg.rendering.shaders.Shader;
import net.primetrg.utils.types.MouseAction;
import net.primetrg.utils.types.MouseButton;

public class HudComponent extends Component {
	private final HudWindow hud;
	private final StringComponent statusComponent;

	public HudComponent(String text, HudWindow hud) {
		this.hud = hud;
		GridComponent grid = new GridComponent();
		grid.addColumnDefinition(new GridDefinition(1f, RelativeUnit.Relative));
		grid.addColumnDefinition(new GridDefinition(RelativeUnit.Auto));

		StringComponent nameComponent = new StringComponent(text);
		nameComponent.setProperty(UIElement.VerticalAlignmentProperty, VerticalAlignment.Center);
		grid.addChild(nameComponent);

		statusComponent = new StringComponent(hud.activated.getValue() ? "-" : "+");
		statusComponent.setProperty(ForegroundProperty, Shader.solid(hud.activated.getValue() ? new Color(255, 0, 0) : new Color(0, 255, 0)));
		statusComponent.setProperty(UIElement.VerticalAlignmentProperty, VerticalAlignment.Center);
		grid.addChild(statusComponent);

		setContent(grid);

		setOnClicked(e -> {
			if (e.button == MouseButton.LEFT && e.action == MouseAction.DOWN) {
				boolean visibility = hud.activated.getValue();
				PrimeTRG.getInstance().guiManager.setHudActive(hud, !visibility);
				e.cancel();
			}
		});
	}

	@Override
	public void update() {
		super.update();

		if (hud.activated.getValue()) {
			statusComponent.setProperty(StringComponent.TextProperty, "-");
			statusComponent.setProperty(ForegroundProperty, Shader.solid(Colors.Red));
		} else {
			statusComponent.setProperty(StringComponent.TextProperty, "+");
			statusComponent.setProperty(ForegroundProperty, Shader.solid(Colors.Green));
		}
	}
}
