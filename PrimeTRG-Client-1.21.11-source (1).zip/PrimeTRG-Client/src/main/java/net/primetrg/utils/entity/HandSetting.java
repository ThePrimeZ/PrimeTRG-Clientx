package net.primetrg.utils.entity;

public enum HandSetting {
	MAIN_HAND, OFF_HAND
}