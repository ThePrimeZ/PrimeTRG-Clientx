/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.utils.types;

import java.util.function.Consumer;

public interface IObservableCollection<T> {
	void addListener(Consumer<IObservableCollection<T>> listener);
	void removeListener(Consumer<IObservableCollection<T>> listener);
}
