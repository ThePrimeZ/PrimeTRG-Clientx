/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.utils.discord.callbacks;

import com.sun.jna.Callback;
import net.primetrg.utils.discord.DiscordUser;

public interface JoinRequestCallback extends Callback {
    void apply(DiscordUser p0);
}
