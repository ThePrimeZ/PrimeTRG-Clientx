package net.primetrg.mixin;

import static net.primetrg.PrimeTRGClient.MC;

import java.awt.Color;
import java.util.List;
import java.util.Objects;

import org.jetbrains.annotations.Nullable;
import java.util.OptionalInt;
import java.util.OptionalDouble;
import com.mojang.blaze3d.systems.RenderSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.primetrg.PrimeTRG;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.colors.Colors;
import net.primetrg.module.modules.render.Tooltips;
import net.primetrg.rendering.shaders.Shader;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.MenuAccess;
import net.minecraft.client.renderer.MapRenderer;
import net.minecraft.client.renderer.state.MapRenderState;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

@Mixin(value = { AbstractContainerScreen.class })
public abstract class AbstractContainerScreenMixin<T extends AbstractContainerMenu> extends Screen implements MenuAccess<T> {
	@Unique
	private Runnable postRender;
	@Unique
	private final MapRenderState mapRenderState = new MapRenderState();

	protected AbstractContainerScreenMixin(Component title) {
		super(title);
	}

	@Shadow
	@Nullable
	protected Slot hoveredSlot;
	@Shadow
	protected int leftPos;
	@Shadow
	protected int topPos;

	private boolean hasItems(ItemStack itemStack) {
		ItemContainerContents compoundTag = itemStack.get(DataComponents.CONTAINER);
		return compoundTag != null;
	}

	@Inject(method = "render", at = @At("TAIL"))
	private void onRender(GuiGraphics context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		Tooltips tooltips = PrimeTRG.getInstance().moduleManager.tooltips;

		if (tooltips.state.getValue() && hoveredSlot != null && !hoveredSlot.getItem().isEmpty()
				&& minecraft.player.inventoryMenu.getCarried().isEmpty()) {
			if (hasItems(hoveredSlot.getItem()) && tooltips.getStorage()) {
				renderShulkerToolTip(context, mouseX, mouseY, 0, 0, hoveredSlot.getItem());
			} else if (hoveredSlot.getItem().getItem() == Items.FILLED_MAP && tooltips.getMap()) {
				drawMapPreview(context, hoveredSlot.getItem(), mouseX, mouseY);
			}
		}
		if (postRender != null) {
			postRender.run();
			postRender = null;
		}
	}

	public boolean renderShulkerToolTip(GuiGraphics context, int offsetX, int offsetY, int mouseX, int mouseY,
			ItemStack stack) {
		try {
			ItemContainerContents compoundTag = stack.get(DataComponents.CONTAINER);
			if (compoundTag == null)
				return false;

			float[] colors = new float[] { 1F, 1F, 1F };
			Item focusedItem = stack.getItem();
			if (focusedItem instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock) {
				try {
					ShulkerBoxBlock shulkerBoxBlock = (ShulkerBoxBlock) bi.getBlock();

					Color c = new Color(Objects.requireNonNull(shulkerBoxBlock.getColor()).getTextureDiffuseColor());
					colors = new float[] { c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f,
							c.getAlpha() / 255f };
				} catch (NullPointerException npe) {
					colors = new float[] { 1F, 1F, 1F };
				}
			}

			int tooltipWidth = 150;
			int nameHeight = 12;

			Font primetrgFont = GuiManager.fontSetting.getValue().getRenderer();
			PrimeTRG.getInstance().render2D.drawStringWithScale(stack.getHoverName().getString(), offsetX + 10, offsetY - 10,
					Shader.solid(Colors.White), 1.0f, primetrgFont);

			drawStorageContents(context, compoundTag.stream().toList(), offsetX, offsetY + nameHeight, mouseX, mouseY, colors);

			context.fill(offsetX, offsetY - nameHeight, offsetX + tooltipWidth, offsetY,
					new Color(0, 0, 0, 128).getRGB());
			PrimeTRG.getInstance().render2D.drawStringWithScale(stack.getHoverName().getString(), offsetX + 5, offsetY - 10,
					Shader.solid(Colors.White), 1.0f, primetrgFont);

		} catch (Exception ignore) {
			return false;
		}
		return true;
	}

	@Unique
	private void drawStorageContents(GuiGraphics context, List<ItemStack> itemStacks, int offsetX, int offsetY, int mouseX, int mouseY,
			float[] colors) {
		try (var pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
				() -> "PrimeTRG Depth Clear",
				MC.getMainRenderTarget().getColorTextureView(),
				OptionalInt.empty(),
				MC.getMainRenderTarget().hasDepth() ? MC.getMainRenderTarget().getDepthTextureView() : null,
				OptionalDouble.of(1.0))) {
		}

		offsetX += 8;
		offsetY -= 82;

		drawBackground(context, offsetX, offsetY, colors);

		int row = 0;
		int i = 0;
		for (ItemStack itemStack : itemStacks) {
			context.renderItem(itemStack, offsetX + 8 + i * 18, offsetY + 7 + row * 18);

			if (mouseX > offsetX + 8 + i * 18 && mouseX < offsetX + 28 + i * 18 && mouseY > offsetY + 7 + row * 18
					&& mouseY < offsetY + 27 + row * 18)
				postRender = () -> context.setTooltipForNextFrame(font, getTooltipFromItem(MC, itemStack),
						itemStack.getTooltipImage(), mouseX, mouseY);

			i++;
			if (i >= 9) {
				i = 0;
				row++;
			}
		}
	}

	private void drawBackground(GuiGraphics context, int x, int y, float[] colors) {
		int red = Math.max(0, Math.min(255, Math.round(colors[0] * 255.0F)));
		int green = Math.max(0, Math.min(255, Math.round(colors[1] * 255.0F)));
		int blue = Math.max(0, Math.min(255, Math.round(colors[2] * 255.0F)));
		int tint = 0xFF000000 | (red << 16) | (green << 8) | blue;
		context.fill(x - 2, y - 2, x + 166, y + 66, 0xE9101420);
		context.fill(x - 2, y - 2, x + 166, y - 1, tint);
		context.fill(x - 2, y + 65, x + 166, y + 66, 0xFF05070D);
		for (int row = 0; row < 3; row++) {
			for (int column = 0; column < 9; column++) {
				int slotX = x + 7 + column * 18;
				int slotY = y + 6 + row * 18;
				context.fill(slotX, slotY, slotX + 17, slotY + 17, 0xA8202938);
				context.fill(slotX, slotY, slotX + 17, slotY + 1, 0x704B5A70);
			}
		}
	}

	private void drawMapPreview(GuiGraphics context, ItemStack stack, int x, int y) {
		int y1 = y - 12;
		int x1 = x + 8;

		MapItemSavedData mapState = MapItem.getSavedData(stack, minecraft.level);

		if (mapState != null) {
			mapState.getHoldingPlayer(minecraft.player);

			x1 += 8;
			y1 += 8;
			double scale = (double) (100 - 16) / 128.0D;

			MapId mapId = stack.get(DataComponents.MAP_ID);
			if (mapId != null) {
				context.pose().pushMatrix();
				context.pose().translate(x1, y1);
				context.pose().scale((float) scale, (float) scale);

				MapRenderer mapRenderer = minecraft.getMapRenderer();
				mapRenderer.extractRenderState(mapId, mapState, mapRenderState);
				context.submitMapRenderState(mapRenderState);
				context.pose().popMatrix();
			}
		}
	}

	@Inject(method = "renderTooltip", at = @At("HEAD"), cancellable = true)
	private void onDrawMouseoverTooltip(GuiGraphics context, int x, int y, CallbackInfo ci) {
		Tooltips tooltips = PrimeTRG.getInstance().moduleManager.tooltips;

		if (hoveredSlot != null && !hoveredSlot.getItem().isEmpty()
				&& minecraft.player.inventoryMenu.getCarried().isEmpty()) {
			if (hoveredSlot.getItem().getItem() == Items.FILLED_MAP && tooltips.state.getValue() && tooltips.getMap())
				ci.cancel();
			else if (hoveredSlot.getItem().getItem() instanceof BlockItem
					&& ((BlockItem) hoveredSlot.getItem().getItem()).getBlock() instanceof ShulkerBoxBlock
					&& tooltips.state.getValue() && tooltips.getStorage())
				ci.cancel();
		}
	}
}