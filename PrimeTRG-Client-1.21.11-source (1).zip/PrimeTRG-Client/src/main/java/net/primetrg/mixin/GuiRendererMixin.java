package net.primetrg.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.primetrg.PrimeTRGClient;
import net.minecraft.client.gui.render.GuiRenderer;

@Mixin(GuiRenderer.class)
public abstract class GuiRendererMixin {
	@Inject(method = "render", at = @At("TAIL"))
	private void primetrg$renderCustomHud(CallbackInfo ci) {
		PrimeTRGClient client = net.primetrg.PrimeTRG.getInstance();
		if (client != null && client.render2D != null)
			client.render2D.render();
	}
}
