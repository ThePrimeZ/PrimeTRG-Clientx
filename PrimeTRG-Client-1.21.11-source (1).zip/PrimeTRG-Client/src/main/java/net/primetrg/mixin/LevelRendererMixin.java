/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 * Licensed under the GNU General Public License, version 3 or later.
 */
package net.primetrg.mixin;

import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.buffers.GpuBufferSlice;

import net.primetrg.PrimeTRG;
import net.primetrg.PrimeTRGClient;
import net.primetrg.event.events.Render3DEvent;
import net.primetrg.rendering.Renderer3D;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.state.LevelRenderState;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
	@Shadow @Final private LevelRenderState levelRenderState;

	@Inject(method = "renderLevel(Lcom/mojang/blaze3d/resource/GraphicsResourceAllocator;Lnet/minecraft/client/DeltaTracker;ZLnet/minecraft/client/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V", at = @At("TAIL"))
	private void onAfterRenderLevel(GraphicsResourceAllocator resourceAllocator, DeltaTracker deltaTracker,
			boolean renderOutline, Camera camera, Matrix4f positionMatrix, Matrix4f basicProjectionMatrix,
			Matrix4f projectionMatrix, GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
		PrimeTRGClient primetrg = PrimeTRG.getInstance();
		Minecraft mc = Minecraft.getInstance();
		if (primetrg == null || primetrg.moduleManager == null || mc.level == null || mc.player == null)
			return;

		PoseStack matrixStack = new PoseStack();
		matrixStack.mulPose(positionMatrix);

		Frustum frustum = new Frustum(positionMatrix, basicProjectionMatrix);
		frustum.prepare(camera.position().x, camera.position().y, camera.position().z);
		Renderer3D renderer = primetrg.render3D;
		renderer.beginFrame(matrixStack, frustum, camera, levelRenderState.cameraRenderState, deltaTracker);
		primetrg.eventManager.Fire(new Render3DEvent(renderer));
		renderer.render();
		if (primetrg.render2D != null)
			primetrg.render2D.captureGameSnapshot();
	}

	@Inject(method = "doesMobEffectBlockSky(Lnet/minecraft/client/Camera;)Z", at = @At("HEAD"), cancellable = true)
	private void onHasBlindnessOrDarknessEffect(Camera camera, org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> cir) {
		PrimeTRGClient client = PrimeTRG.getInstance();
		if (client != null && client.moduleManager != null && client.moduleManager.norender.state.getValue())
			cir.setReturnValue(false);
	}

	@Inject(method = "extractBlockOutline(Lnet/minecraft/client/Camera;Lnet/minecraft/client/renderer/state/LevelRenderState;)V", at = @At("HEAD"), cancellable = true)
	private void onExtractBlockOutline(Camera camera, LevelRenderState renderState, CallbackInfo ci) {
		PrimeTRGClient client = PrimeTRG.getInstance();
		if (client != null && client.moduleManager != null && client.moduleManager.freecam.state.getValue())
			ci.cancel();
	}

}
