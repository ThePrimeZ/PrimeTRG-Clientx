/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.primetrg.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.blaze3d.vertex.PoseStack;
import net.primetrg.PrimeTRG;
import net.primetrg.PrimeTRGClient;
import net.minecraft.client.renderer.GameRenderer;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "bobView(Lcom/mojang/blaze3d/vertex/PoseStack;F)V", at = @At("HEAD"), cancellable = true)
	private void onBobViewWhenHurt(PoseStack matrixStack, float tickProgress, CallbackInfo ci) {
		PrimeTRGClient primetrg = PrimeTRG.getInstance();
		if (primetrg != null && primetrg.moduleManager != null && primetrg.moduleManager.norender.state.getValue()) {
			ci.cancel();
		}
	}

	// TODO: No Render TOTEMS
//	@Inject(method = "displayItemActivation", at = @At("HEAD"), cancellable = true)
//	private void onShowFloatingItem(ItemStack floatingItem, CallbackInfo info) {
//		PrimeTRGClient primetrg = PrimeTRG.getInstance();
//		if (primetrg == null)
//			return;
//
//		NoRender norender = primetrg.moduleManager.norender;
//		if (floatingItem.getItem() == Items.TOTEM_OF_UNDYING && norender.state.getValue()
//				&& norender.getNoTotemAnimation()) {
//			info.cancel();
//		}
//	}
}
