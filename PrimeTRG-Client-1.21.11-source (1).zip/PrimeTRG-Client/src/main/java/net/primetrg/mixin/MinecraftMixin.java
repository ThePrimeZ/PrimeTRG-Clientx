/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.primetrg.mixin;

import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.primetrg.PrimeTRG;
import net.primetrg.PrimeTRGClient;
import net.primetrg.event.events.StartAttackEvent;
import net.primetrg.event.events.SubtickEvent;
import net.primetrg.event.events.TickEvent;
import net.minecraft.CrashReport;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.Options;
import net.minecraft.client.User;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

	private boolean primetrgLoaded = false;
	
	@Shadow
	private int rightClickDelay;
	@Shadow
	@Final
	private User user;

	@Shadow
	@Final
	private MouseHandler mouseHandler;

	@Shadow
	public ClientLevel level;

	@Shadow
	public LocalPlayer player;

	private User primetrgSession;

	private long primetrgLastSubtickNanos;

	@Shadow
	public abstract boolean isWindowActive();

	@Shadow
	public abstract void delayCrash(CrashReport crashReport);

	@Shadow
	@Nullable
	public HitResult hitResult;
	
	@Shadow
	@Final
	public Options options;

	@Inject(at = @At("HEAD"), method = "onResourceLoadFinished(Lnet/minecraft/client/GameLoadCookie;)V")
	private void onfinishedloading(CallbackInfo info) {
		if(primetrgLoaded)
			return;

		primetrgLoaded = true;
		try {
			PrimeTRG.getInstance().loadAssets();
		} catch (Throwable t) {
			delayCrash(CrashReport.forThrowable(t, "Initializing PrimeTRG Client"));
		}
	}

	@Inject(at = @At("HEAD"), method = "tick()V")
	public void onPreTick(CallbackInfo info) {
		if (level != null && player != null) {
			TickEvent.Pre updateEvent = new TickEvent.Pre();
			PrimeTRG.getInstance().eventManager.Fire(updateEvent);
		}
	}

	@Inject(at = @At("TAIL"), method = "tick()V")
	public void onPostTick(CallbackInfo info) {
		if (level != null && player != null) {
			TickEvent.Post updateEvent = new TickEvent.Post();
			PrimeTRG.getInstance().eventManager.Fire(updateEvent);
		}
	}

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MouseHandler;handleAccumulatedMovement()V", shift = At.Shift.AFTER), method = "runTick(Z)V")
	public void onSubtick(boolean advanceGameTime, CallbackInfo info) {
		long now = System.nanoTime();
		if (primetrgLastSubtickNanos == 0L)
			primetrgLastSubtickNanos = now;
		float delta = (now - primetrgLastSubtickNanos) / 1_000_000.0f;
		primetrgLastSubtickNanos = now;

		if (level != null && player != null) {
			SubtickEvent updateEvent = new SubtickEvent(delta);
			PrimeTRG.getInstance().eventManager.Fire(updateEvent);
		}
	}

	@Inject(at = { @At("HEAD") }, method = { "getUser()Lnet/minecraft/client/User;" }, cancellable = true)
	private void onGetSession(CallbackInfoReturnable<User> cir) {
		if (primetrgSession == null)
			return;
		cir.setReturnValue(primetrgSession);
	}

	@Redirect(at = @At(value = "FIELD", target = "Lnet/minecraft/client/Minecraft;user:Lnet/minecraft/client/User;", opcode = Opcodes.GETFIELD, ordinal = 0), method = {
			"getUser()Lnet/minecraft/client/User;" })
	private User getSessionForSessionProperties(Minecraft mc) {
		if (primetrgSession != null)
			return primetrgSession;
		return user;
	}

	@Inject(at = { @At(value = "HEAD") }, method = { "close()V" })
	private void onClose(CallbackInfo ci) {
		try {
			PrimeTRG.getInstance().endClient();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Inject(at = { @At(value = "HEAD") }, method = { "pauseGame(Z)V" })
	private void onOpenPauseMenu(boolean pause, CallbackInfo ci) {
		PrimeTRGClient primetrg = PrimeTRG.getInstance();

		if (primetrg.guiManager != null) {
			primetrg.guiManager.setClickGuiOpen(false);
		}
	}

    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true)
    private void startAttack(CallbackInfoReturnable<Boolean> cir) {
    	Entity target = null;
    	if(hitResult.getType() == HitResult.Type.ENTITY) {
    		target = ((EntityHitResult)hitResult).getEntity();
    	}
    	
    	StartAttackEvent event = new StartAttackEvent(target);
    	PrimeTRG.getInstance().eventManager.Fire(event);
    	
    	if(event.isCancelled()) {
            cir.setReturnValue(false);
    	}
    }

	// TODO: InactivityFrameLimiter class... i guess.. :/
	/*
	 * @Inject(method = "getCurrentFps", at = @At("HEAD"), cancellable = true)
	 * private void onGetCurrentFps(CallbackInfoReturnable<Integer> info) { if
	 * (PrimeTRG.getInstance().moduleManager != null) { FocusFps focusfps = (FocusFps)
	 * PrimeTRG.getInstance().moduleManager.focusfps; if (focusfps.state.getValue() &&
	 * !isWindowFocused()) {
	 * info.setReturnValue(Math.min(focusfps.getFps().intValue(),
	 * this.options.getMaxFps().getValue())); } } }
	 */
}
