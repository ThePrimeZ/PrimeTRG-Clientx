package net.primetrg.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.primetrg.PrimeTRG;
import net.primetrg.managers.rotation.goals.Goal;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.phys.Vec3;

@Mixin(FireworkRocketEntity.class)
public class FireworkRocketEntityMixin {
	@Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getLookAngle()Lnet/minecraft/world/phys/Vec3;"))
	private Vec3 onGetLookAngle(LivingEntity instance) {
		Minecraft mc = Minecraft.getInstance();
		if (instance == mc.player) {
			Goal<?> goal = PrimeTRG.getInstance().rotationManager.getGoal();
			if (goal != null && goal.isFakeRotation()) {
				Float serverYaw = PrimeTRG.getInstance().rotationManager.getServerYaw();
				Float serverPitch = PrimeTRG.getInstance().rotationManager.getServerPitch();
				if (serverYaw != null && serverPitch != null) {
					return instance.calculateViewVector(serverPitch, serverYaw);
				}
			}
		}
		return instance.getLookAngle();
	}
}
