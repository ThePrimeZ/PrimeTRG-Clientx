package net.primetrg.mixin;

import net.primetrg.PrimeTRG;
import net.primetrg.PrimeTRGClient;
import net.primetrg.module.modules.movement.Freecam;
import net.primetrg.module.modules.render.NoRender;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow private boolean initialized;
    @Shadow private Entity entity;
    @Shadow private Level level;
    @Shadow private boolean detached;
    @Shadow private float partialTickTime;

    /** 1.21.11 consolidates the old setEntity/alignWithEntity hooks into Camera#setup. */
    @Inject(method = "setup(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/Entity;ZZF)V",
            at = @At("HEAD"), cancellable = true)
    private void primetrg$keepFreecamCamera(Level level, Entity focusedEntity, boolean thirdPerson,
                                            boolean inverseView, float tickDelta, CallbackInfo ci) {
        PrimeTRGClient client = PrimeTRG.getInstance();
        if (client == null || client.moduleManager == null) return;
        Freecam freecam = client.moduleManager.freecam;
        if (freecam.state.getValue() && this.entity != null) {
            this.initialized = true;
            this.level = level;
            this.partialTickTime = tickDelta;
            this.detached = thirdPerson;
            ci.cancel();
        }
    }

    @Inject(method = "getFluidInCamera()Lnet/minecraft/world/level/material/FogType;",
            at = @At("HEAD"), cancellable = true)
    private void primetrg$removeFreecamWaterFog(CallbackInfoReturnable<FogType> cir) {
        PrimeTRGClient client = PrimeTRG.getInstance();
        if (client == null || client.moduleManager == null) return;
        Freecam freecam = client.moduleManager.freecam;
        NoRender noRender = client.moduleManager.norender;
        if (freecam.state.getValue() || (noRender.state.getValue() && noRender.getNoLiquidOverlay())) {
            cir.setReturnValue(FogType.NONE);
        }
    }
}
