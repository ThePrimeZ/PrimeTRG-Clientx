/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.command.commands;

import net.primetrg.PrimeTRG;
import net.primetrg.PrimeTRGClient;
import net.primetrg.command.Command;
import net.primetrg.gui.GuiManager;
import net.primetrg.gui.font.UIFont;
import net.primetrg.managers.CommandManager;
import net.primetrg.command.InvalidSyntaxException;

public class CmdFont extends Command {

    public CmdFont() {
        super("font", "Sets the HUD font.", "[set] [value]");
    }

    @Override
    public void runCommand(String[] parameters) throws InvalidSyntaxException {
        if (parameters.length != 2)
            throw new InvalidSyntaxException(this);

        PrimeTRGClient primetrg = PrimeTRG.getInstance();

        switch (parameters[0]) {
            case "set":
                try {
                    String font = parameters[1];
                    UIFont t = primetrg.fontManager.fonts.get(font);
                    if (t != null) {
                    	GuiManager.fontSetting.setFontName(font);
                    }
                } catch (Exception e) {
                    CommandManager.sendChatMessage("Invalid value.");
                }
                break;
            default:
                throw new InvalidSyntaxException(this);
        }
    }

    @Override
    public String[] getAutocorrect(String previousParameter) {
        switch (previousParameter) {
            case "set":
                PrimeTRGClient primetrg = PrimeTRG.getInstance();

                String[] suggestions = new String[primetrg.fontManager.fonts.size()];

                int i = 0;
                for (String fontName : primetrg.fontManager.fonts.keySet())
                    suggestions[i++] = fontName;

                return suggestions;
            default:
                return new String[]{"set"};
        }
    }
}