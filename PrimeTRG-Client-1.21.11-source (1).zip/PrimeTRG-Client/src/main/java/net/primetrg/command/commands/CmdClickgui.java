/*
 * PrimeTRG Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.primetrg.command.commands;

import com.mojang.blaze3d.platform.InputConstants;
import net.primetrg.PrimeTRG;
import net.primetrg.command.Command;
import net.primetrg.command.InvalidSyntaxException;
import net.primetrg.utils.input.Keybind;

public class CmdClickgui extends Command {

    public CmdClickgui() {
        super("clickgui", "Allows the player to see chest locations through ESP", "[set/open] [value]");
    }

    @Override
    public void runCommand(String[] parameters) throws InvalidSyntaxException {
        switch (parameters[0]) {
            case "set":
                if (parameters.length != 2)
                    throw new InvalidSyntaxException(this);
                char keybind = Character.toUpperCase(parameters[1].charAt(0));
                PrimeTRG.getInstance().guiManager.clickGuiButton.setValue(Keybind.from(InputConstants.Type.KEYBOARD.getOrCreate((int) keybind)));
                break;
            case "open":
                PrimeTRG.getInstance().guiManager.setClickGuiOpen(true);
                break;
            default:
                throw new InvalidSyntaxException(this);
        }
    }

    @Override
    public String[] getAutocorrect(String previousParameter) {
        switch (previousParameter) {
            default:
                return new String[]{"set", "open"};
        }
    }
}
