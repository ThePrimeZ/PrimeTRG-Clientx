# PrimeTRG Client

PrimeTRG Client targets Minecraft Java Edition 1.21.11 on Fabric and is built from the Aoba Client codebase while retaining its modular architecture, command framework, configurable GUI, addon support, account tools, and client utilities.

## Build requirements

- Java 21 (JDK)
- Gradle wrapper (included)
- Network access to Fabric Maven, Maven Central, and Modrinth Maven for dependency resolution

Build and test with `./gradlew clean test build`. The remapped JAR is written to `build/libs/`; the GitHub Actions workflow verifies it and publishes releases as `PrimeTRG-Client-1.21.11.jar`.

## Runtime dependencies

- Minecraft 1.21.11
- Fabric Loader 0.19.5 or newer
- Fabric API 0.141.6+1.21.11

Sodium, Lithium, Iris, and Mod Menu are optional integrations used by the client.

## License and attribution

This project is derived from Aoba Client. Original contributors and copyright notices are retained where applicable. Licensed under GPL-3.0-only; see [LICENSE](LICENSE).
